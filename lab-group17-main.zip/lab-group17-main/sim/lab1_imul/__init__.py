#=========================================================================
# lab1_imul
#=========================================================================

from lab1_imul.IntMulFL   import IntMulFL
from lab1_imul.IntMulBase import IntMulBase
from lab1_imul.IntMulAlt  import IntMulAlt
from lab1_imul.IntMulAltV2 import IntMulAltV2

