#=========================================================================
# IntMulFL_test
#=========================================================================

import pytest

from random import randint

from pymtl3 import *
from pymtl3.stdlib.test_utils import mk_test_case_table, run_sim
from pymtl3.stdlib.stream import StreamSourceFL, StreamSinkFL

from lab1_imul.IntMulFL import IntMulFL

#-------------------------------------------------------------------------
# TestHarness
#-------------------------------------------------------------------------

class TestHarness( Component ):

  def construct( s, imul ):

    # Instantiate models

    s.src  = StreamSourceFL( Bits64 )
    s.sink = StreamSinkFL( Bits32 )
    s.imul = imul

    # Connect

    s.src.ostream  //= s.imul.istream
    s.imul.ostream //= s.sink.istream

  def done( s ):
    return s.src.done() and s.sink.done()

  def line_trace( s ):
    return s.src.line_trace() + " > " + s.imul.line_trace() + " > " + s.sink.line_trace()

#-------------------------------------------------------------------------
# mk_imsg/mk_omsg
#-------------------------------------------------------------------------

# Make input message, truncate ints to ensure they fit in 32 bits.

def mk_imsg( a, b ):
  return concat( Bits32( a, trunc_int=True ), Bits32( b, trunc_int=True ) )

# Make output message, truncate ints to ensure they fit in 32 bits.

def mk_omsg( a ):
  return Bits32( a, trunc_int=True )

#----------------------------------------------------------------------
# Test Case: combinations of zero, one, and negative one
#----------------------------------------------------------------------

zero_one_neg_one_msgs = [
  # Zero tests
  mk_imsg(  0,  0 ), mk_omsg(   0 ),
  mk_imsg(  0,  1 ), mk_omsg(   0 ),
  mk_imsg(  0, -1 ), mk_omsg(   0 ),
  mk_imsg(  0, 42 ), mk_omsg(   0 ),
  mk_imsg(  0,-42 ), mk_omsg(   0 ),
  mk_imsg( 42,  0 ), mk_omsg(   0 ),
  mk_imsg(-42,  0 ), mk_omsg(   0 ),
  
  # One tests
  mk_imsg(  1,  1 ), mk_omsg(   1 ),
  mk_imsg(  1, -1 ), mk_omsg(  -1 ),
  mk_imsg( -1,  1 ), mk_omsg(  -1 ),
  mk_imsg( -1, -1 ), mk_omsg(   1 ),
  mk_imsg(  1, 123), mk_omsg( 123 ),
  mk_imsg(123,  1 ), mk_omsg( 123 ),
  mk_imsg( -1, 123), mk_omsg(-123 ),
  mk_imsg(123, -1 ), mk_omsg(-123 ),
]

#----------------------------------------------------------------------
# Test Case: small positive * positive
#----------------------------------------------------------------------

small_pos_pos_msgs = [
  mk_imsg(  2,  3 ), mk_omsg(   6 ),
  mk_imsg(  4,  5 ), mk_omsg(  20 ),
  mk_imsg(  3,  4 ), mk_omsg(  12 ),
  mk_imsg( 10, 13 ), mk_omsg( 130 ),
  mk_imsg(  8,  7 ), mk_omsg(  56 ),
  mk_imsg( 15, 15 ), mk_omsg( 225 ),
  mk_imsg(  7, 11 ), mk_omsg(  77 ),
]

#----------------------------------------------------------------------
# Test Case: small negative * positive
#----------------------------------------------------------------------
small_neg_pos_msgs = [
  mk_imsg( -2,  3 ), mk_omsg(  -6 ),
  mk_imsg( -4,  5 ), mk_omsg( -20 ),
  mk_imsg( -3,  4 ), mk_omsg( -12 ),
  mk_imsg(-10, 13 ), mk_omsg(-130 ),
  mk_imsg( -8,  7 ), mk_omsg( -56 ),
  mk_imsg(-15, 15 ), mk_omsg(-225 ),
  mk_imsg( -7, 11 ), mk_omsg( -77 ),
]

#----------------------------------------------------------------------
# Test Case: small positive * negative
#----------------------------------------------------------------------
small_pos_neg_msgs = [
  mk_imsg(  2, -3 ), mk_omsg(  -6 ),
  mk_imsg(  4, -5 ), mk_omsg( -20 ),
  mk_imsg(  3, -4 ), mk_omsg( -12 ),
  mk_imsg( 10,-13 ), mk_omsg(-130 ),
  mk_imsg(  8, -7 ), mk_omsg( -56 ),
  mk_imsg( 15,-15 ), mk_omsg(-225 ),
  mk_imsg(  7,-11 ), mk_omsg( -77 ),
]

#----------------------------------------------------------------------
# Test Case: small negative * negative
#----------------------------------------------------------------------
small_neg_neg_msgs = [
  mk_imsg( -2, -3 ), mk_omsg(   6 ),
  mk_imsg( -4, -5 ), mk_omsg(  20 ),
  mk_imsg( -3, -4 ), mk_omsg(  12 ),
  mk_imsg(-10,-13 ), mk_omsg( 130 ),
  mk_imsg( -8, -7 ), mk_omsg(  56 ),
  mk_imsg(-15,-15 ), mk_omsg( 225 ),
  mk_imsg( -7,-11 ), mk_omsg(  77 ),
]

#----------------------------------------------------------------------
# Test Case: large positive * positive
#----------------------------------------------------------------------
large_pos_pos_msgs = [
  mk_imsg( 1000, 2000 ), mk_omsg( 2000000 ),
  mk_imsg( 5000, 6000 ), mk_omsg( 30000000 ),
  mk_imsg( 12345, 6789 ), mk_omsg( 83810205 ),
  mk_imsg( 32767, 32767 ), mk_omsg( 1073676289 ),
  mk_imsg( 65535, 65535 ), mk_omsg( 4294836225 ),
]

#----------------------------------------------------------------------
# Test Case: large positive * negative
#----------------------------------------------------------------------
large_pos_neg_msgs = [
  mk_imsg( 1000, -2000 ), mk_omsg( -2000000 ),
  mk_imsg( 5000, -6000 ), mk_omsg( -30000000 ),
  mk_imsg( 12345, -6789 ), mk_omsg( -83810205 ),
  mk_imsg( 32767, -32767 ), mk_omsg( -1073676289 ),
  mk_imsg( 65535, -65535 ), mk_omsg( -4294836225 ),
]

#----------------------------------------------------------------------
# Test Case: large negative * positive
#----------------------------------------------------------------------
large_neg_pos_msgs = [
  mk_imsg( -1000, 2000 ), mk_omsg( -2000000 ),
  mk_imsg( -5000, 6000 ), mk_omsg( -30000000 ),
  mk_imsg( -12345, 6789 ), mk_omsg( -83810205 ),
  mk_imsg( -32767, 32767 ), mk_omsg( -1073676289 ),
  mk_imsg( -65535, 65535 ), mk_omsg( -4294836225 ),
]

#----------------------------------------------------------------------
# Test Case: large negative * negative
#----------------------------------------------------------------------
large_neg_neg_msgs = [
  mk_imsg( -1000, -2000 ), mk_omsg( 2000000 ),
  mk_imsg( -5000, -6000 ), mk_omsg( 30000000 ),
  mk_imsg( -12345, -6789 ), mk_omsg( 83810205 ),
  mk_imsg( -32767, -32767 ), mk_omsg( 1073676289 ),
  mk_imsg( -65535, -65535 ), mk_omsg( 4294836225 ),
]

#----------------------------------------------------------------------
# Test Case: low order bits masked off
#----------------------------------------------------------------------
low_bits_masked_msgs = [
  # Numbers with low 4 bits zero (divisible by 16)
  mk_imsg( 0x1230, 0x4560 ), mk_omsg( 0x1230 * 0x4560 ),
  mk_imsg( 0x7890, 0xABC0 ), mk_omsg( 0x7890 * 0xABC0 ),
  mk_imsg( 0x1000, 0x2000 ), mk_omsg( 0x1000 * 0x2000 ),
  mk_imsg( 0xFF00, 0x0F00 ), mk_omsg( 0xFF00 * 0x0F00 ),
  # Numbers with low 8 bits zero (divisible by 256)
  mk_imsg( 0x1200, 0x3400 ), mk_omsg( 0x1200 * 0x3400 ),
  mk_imsg( 0xAB00, 0xCD00 ), mk_omsg( 0xAB00 * 0xCD00 ),
]

#----------------------------------------------------------------------
# Test Case: middle bits masked off
#----------------------------------------------------------------------
middle_bits_masked_msgs = [
  # Pattern: high and low bits set, middle zeros
  mk_imsg( 0xF00F, 0xE00E ), mk_omsg( 0xF00F * 0xE00E ),
  mk_imsg( 0x8001, 0x4002 ), mk_omsg( 0x8001 * 0x4002 ),
  mk_imsg( 0xFF0F, 0x7F07 ), mk_omsg( 0xFF0F * 0x7F07 ),
  mk_imsg( 0xC003, 0x9009 ), mk_omsg( 0xC003 * 0x9009 ),
  # More complex middle-zero patterns
  mk_imsg( 0xF0F0, 0x0F0F ), mk_omsg( 0xF0F0 * 0x0F0F ),
  mk_imsg( 0xAAAA, 0x5555 ), mk_omsg( 0xAAAA * 0x5555 ),
]

#----------------------------------------------------------------------
# Test Case: sparse numbers (many zeros, few ones)
#----------------------------------------------------------------------
sparse_msgs = [
  # Only 1-2 bits set
  mk_imsg( 0x00000001, 0x00000001 ), mk_omsg( 1 ),
  mk_imsg( 0x00000002, 0x00000004 ), mk_omsg( 8 ),
  mk_imsg( 0x00000080, 0x00000100 ), mk_omsg( 32768 ),
  mk_imsg( 0x00008000, 0x00010000 ), mk_omsg( 2147483648 ),
  mk_imsg( 0x80000000, 0x00000001 ), mk_omsg( 2147483648 ),
  # Powers of 2
  mk_imsg( 0x00000008, 0x00000010 ), mk_omsg( 128 ),
  mk_imsg( 0x00000040, 0x00000020 ), mk_omsg( 2048 ),
  mk_imsg( 0x00001000, 0x00002000 ), mk_omsg( 33554432 ),
]

#----------------------------------------------------------------------
# Test Case: dense numbers (many ones, few zeros)
#----------------------------------------------------------------------
dense_msgs = [
  # All ones except few bits
  mk_imsg( 0xFFFFFFFE, 0xFFFFFFFD ), mk_omsg( 0xFFFFFFFE * 0xFFFFFFFD ),
  mk_imsg( 0xFFFFFFF0, 0xFFFFFF0F ), mk_omsg( 0xFFFFFFF0 * 0xFFFFFF0F ),
  mk_imsg( 0xFFFF0000, 0x0000FFFF ), mk_omsg( 0xFFFF0000 * 0x0000FFFF ),
  mk_imsg( 0xF0F0F0F0, 0x0F0F0F0F ), mk_omsg( 0xF0F0F0F0 * 0x0F0F0F0F ),
  # Nearly all ones
  mk_imsg( 0xFFFFFF00, 0xFFFF00FF ), mk_omsg( 0xFFFFFF00 * 0xFFFF00FF ),
  mk_imsg( 0x7FFFFFFF, 0x7FFFFFFF ), mk_omsg( 0x7FFFFFFF * 0x7FFFFFFF ),
]

#----------------------------------------------------------------------
# Test Case: corner cases for alternative designs
#----------------------------------------------------------------------
corner_case_msgs = [
  # Maximum positive 32-bit signed integer
  mk_imsg( 0x7FFFFFFF, 1 ), mk_omsg( 0x7FFFFFFF ),
  mk_imsg( 0x7FFFFFFF, 2 ), mk_omsg( 0xFFFFFFFE ),
  # Minimum negative 32-bit signed integer
  mk_imsg( 0x80000000, 1 ), mk_omsg( 0x80000000 ),
  mk_imsg( 0x80000000, -1 ), mk_omsg( 0x80000000 ),
  # Boundary cases that might cause overflow in intermediate calculations
  mk_imsg( 0x7FFFFFFF, 0x7FFFFFFF ), mk_omsg( 0x7FFFFFFF * 0x7FFFFFFF ),
  mk_imsg( 0x80000000, 0x80000000 ), mk_omsg( 0x80000000 * 0x80000000 ),
  # Cases that test sign extension
  mk_imsg( 0x8000, 0x8000 ), mk_omsg( 0x40000000 ),
  mk_imsg( 0xFFFF8000, 0xFFFF8000 ), mk_omsg( 0xFFFF8000 * 0xFFFF8000 ),
  # Alternating bit patterns
  mk_imsg( 0xAAAAAAAA, 0x55555555 ), mk_omsg( 0xAAAAAAAA * 0x55555555 ),
  mk_imsg( 0x33333333, 0xCCCCCCCC ), mk_omsg( 0x33333333 * 0xCCCCCCCC ),
]

#----------------------------------------------------------------------
# Test Case: random tests
#----------------------------------------------------------------------
def mk_random_msgs( num_tests=20 ):
  msgs = []
  for _ in range(num_tests):
    a = randint(-1000, 1000)
    b = randint(-1000, 1000)
    result = a * b
    msgs.extend([ mk_imsg(a, b), mk_omsg(result) ])
  return msgs

def mk_random_large_msgs( num_tests=20 ):
  msgs = []
  for _ in range(num_tests):
    a = randint(-2**31, 2**31-1)
    b = randint(-2**31, 2**31-1)
    result = a * b
    msgs.extend([ mk_imsg(a, b), mk_omsg(result) ])
  return msgs

random_msgs = mk_random_msgs(10)
random_large_msgs = mk_random_large_msgs(10)

#-------------------------------------------------------------------------
# Test Case Table
#-------------------------------------------------------------------------

test_case_table = mk_test_case_table([
  (                        "msgs                     src_delay sink_delay"),
  # Basic functionality tests
  [ "zero_one_neg_one",     zero_one_neg_one_msgs,    0,        0          ],
  [ "small_pos_pos",        small_pos_pos_msgs,       0,        0          ],
  [ "small_neg_pos",        small_neg_pos_msgs,       0,        0          ],
  [ "small_pos_neg",        small_pos_neg_msgs,       0,        0          ],
  [ "small_neg_neg",        small_neg_neg_msgs,       0,        0          ],
  
  # Large number tests
  [ "large_pos_pos",        large_pos_pos_msgs,       0,        0          ],
  [ "large_pos_neg",        large_pos_neg_msgs,       0,        0          ],
  [ "large_neg_pos",        large_neg_pos_msgs,       0,        0          ],
  [ "large_neg_neg",        large_neg_neg_msgs,       0,        0          ],
  
  # Bit pattern tests
  [ "low_bits_masked",      low_bits_masked_msgs,     0,        0          ],
  [ "middle_bits_masked",   middle_bits_masked_msgs,  0,        0          ],
  [ "sparse",               sparse_msgs,              0,        0          ],
  [ "dense",                dense_msgs,               0,        0          ],
  [ "corner_cases",         corner_case_msgs,         0,        0          ],
  
  # Random tests
  [ "random",               random_msgs,              0,        0          ],
  [ "random_large",         random_large_msgs,        0,        0          ],
  
  # Tests with timing delays
  [ "zero_one_neg_one_delay", zero_one_neg_one_msgs,  2,        1          ],
  [ "small_pos_pos_delay",    small_pos_pos_msgs,     1,        2          ],
  [ "small_neg_pos_delay",    small_neg_pos_msgs,     3,        1          ],
  [ "large_pos_pos_delay",    large_pos_pos_msgs,     2,        3          ],
  [ "sparse_delay",           sparse_msgs,            4,        2          ],
  [ "dense_delay",            dense_msgs,             1,        4          ],
  [ "corner_cases_delay",     corner_case_msgs,       3,        3          ],
  [ "random_delay",           random_msgs,            3,        1          ],
  [ "random_large_delay",     random_large_msgs,      5,        2          ],
])

#-------------------------------------------------------------------------
# TestHarness
#-------------------------------------------------------------------------

@pytest.mark.parametrize( **test_case_table )
def test( test_params, cmdline_opts ):

  th = TestHarness( IntMulFL() )

  th.set_param("top.src.construct",
    msgs=test_params.msgs[::2],
    initial_delay=test_params.src_delay+3,
    interval_delay=test_params.src_delay )

  th.set_param("top.sink.construct",
    msgs=test_params.msgs[1::2],
    initial_delay=test_params.sink_delay+3,
    interval_delay=test_params.sink_delay )

  run_sim( th, cmdline_opts, duts=['imul'] )