#!/bin/bash

# Check if at least one variant is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <variant1> [variant2] [variant3] ..."
    echo "Example: $0 Base Alt AltV2"
    exit 1
fi

# Use command line arguments as variants
variants=("$@")

echo "Processing variants: ${variants[*]}"
echo

# Loop through each variant and execute verilator command
for variant in "${variants[@]}"; do
    echo "Processing IntMul${variant}.v..."
    verilator -sv -E -P --flatten lab1_imul/IntMul${variant}.v --top-module lab1_imul_IntMul${variant} -I vc/regs.v -I vc/arithmetic.v -I vc/trace.v -I vc/muxes.v -I vc/counters.v > lab1_imul/IntMul${variant}_pickled.v

    # Check if the command was successful
    if [ $? -eq 0 ]; then
        echo "Successfully processed IntMul${variant}.v -> IntMul${variant}_pickled.v"
    else
        echo "Error processing IntMul${variant}.v"
    fi
done

echo "All variants processed."
