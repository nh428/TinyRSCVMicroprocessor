if [ $# -eq 0 ]; then
    echo "Usage: $0 <variant1> [variant2] [variant3] ..."
    echo "Example: $0 Base Alt AltV2"
    exit 1
fi

variants=("$@")


cd /home/ism27/ece4750/lab-group17/synopsys-dc-synth
for variant in "${variants[@]}"; do
    x_arg="set variant ${variant}"
    echo "Running synthesis for variant: ${variant}"
    dc_shell-xg-t -f /home/ism27/ece4750/lab-group17/synopsys-dc-synth/run_synthesis.tcl -x "${x_arg}" | tee synthesis_${variant}.log
done

cd /home/ism27/ece4750/lab-group17/sim