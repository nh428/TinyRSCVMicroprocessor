#=========================================================================
# slt
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """
    csrr x1, mngr2proc < 4
    csrr x2, mngr2proc < 5
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    slt x3, x1, x2
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    csrw proc2mngr, x3 > 1
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
  """

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------

def gen_dest_dep_test():
  return [
    gen_rr_dest_dep_test( 5, "slt", 1, 2, 1 ),
    gen_rr_dest_dep_test( 4, "slt", 3, 4, 1 ),
    gen_rr_dest_dep_test( 3, "slt", 5, 6, 1 ),
    gen_rr_dest_dep_test( 2, "slt", 7, 8, 1 ),
    gen_rr_dest_dep_test( 1, "slt", 9, 10, 1 ),
    gen_rr_dest_dep_test( 0, "slt", 11, 12, 1 ),
  ]

#-------------------------------------------------------------------------
# gen_src0_dep_test
#-------------------------------------------------------------------------

def gen_src0_dep_test():
  return [
    gen_rr_src0_dep_test( 5, "slt", 1, 2, 1 ),
    gen_rr_src0_dep_test( 4, "slt", 3, 4, 1 ),
    gen_rr_src0_dep_test( 3, "slt", 5, 6, 1 ),
    gen_rr_src0_dep_test( 2, "slt", 7, 8, 1 ),
    gen_rr_src0_dep_test( 1, "slt", 9, 10, 1 ),
    gen_rr_src0_dep_test( 0, "slt", 11, 12, 1 ),
  ]

#-------------------------------------------------------------------------
# gen_src1_dep_test
#-------------------------------------------------------------------------

def gen_src1_dep_test():
  return [
    gen_rr_src1_dep_test( 5, "slt", 15, 14, 0 ),
    gen_rr_src1_dep_test( 4, "slt", 16, 15, 0 ),
    gen_rr_src1_dep_test( 3, "slt", 17, 16, 0 ),
    gen_rr_src1_dep_test( 2, "slt", 18, 17, 0 ),
    gen_rr_src1_dep_test( 1, "slt", 19, 18, 0 ),
    gen_rr_src1_dep_test( 0, "slt", 20, 19, 0 ),
  ]

#-------------------------------------------------------------------------
# gen_srcs_dep_test
#-------------------------------------------------------------------------

def gen_srcs_dep_test():
  return [
    gen_rr_srcs_dep_test( 5, "slt", 10, 20, 1 ),
    gen_rr_srcs_dep_test( 4, "slt", 11, 21, 1 ),
    gen_rr_srcs_dep_test( 3, "slt", 12, 22, 1 ),
    gen_rr_srcs_dep_test( 2, "slt", 13, 23, 1 ),
    gen_rr_srcs_dep_test( 1, "slt", 14, 24, 1 ),
    gen_rr_srcs_dep_test( 0, "slt", 15, 25, 1 ),
  ]

#-------------------------------------------------------------------------
# gen_srcs_dest_test
#-------------------------------------------------------------------------

def gen_srcs_dest_test():
  return [
    gen_rr_src0_eq_dest_test( "slt", 25, 30, 1 ),
    gen_rr_src1_eq_dest_test( "slt", 35, 30, 0 ),
    gen_rr_src0_eq_src1_test( "slt", 40, 0 ),
    gen_rr_srcs_eq_dest_test( "slt", 45, 0 ),
  ]

#-------------------------------------------------------------------------
# gen_value_test
#-------------------------------------------------------------------------

def gen_value_test():
  return [

    # Basic comparison tests
    gen_rr_value_test( "slt", 0x00000000, 0x00000000, 0x00000000 ), # 0 < 0 = false
    gen_rr_value_test( "slt", 0x00000000, 0x00000001, 0x00000001 ), # 0 < 1 = true
    gen_rr_value_test( "slt", 0x00000001, 0x00000000, 0x00000000 ), # 1 < 0 = false
    gen_rr_value_test( "slt", 0x00000001, 0x00000001, 0x00000000 ), # 1 < 1 = false

    # Small positive number comparisons
    gen_rr_value_test( "slt", 0x00000003, 0x00000007, 0x00000001 ), # 3 < 7 = true
    gen_rr_value_test( "slt", 0x00000007, 0x00000003, 0x00000000 ), # 7 < 3 = false

    # Test with negative numbers (signed comparison)
    gen_rr_value_test( "slt", 0xffffffff, 0x00000000, 0x00000001 ), # -1 < 0 = true
    gen_rr_value_test( "slt", 0x00000000, 0xffffffff, 0x00000000 ), # 0 < -1 = false
    gen_rr_value_test( "slt", 0xffffffff, 0xffffffff, 0x00000000 ), # -1 < -1 = false

    # Test with large negative vs positive
    gen_rr_value_test( "slt", 0x80000000, 0x00000001, 0x00000001 ), # most neg < 1 = true
    gen_rr_value_test( "slt", 0x00000001, 0x80000000, 0x00000000 ), # 1 < most neg = false
    gen_rr_value_test( "slt", 0x80000000, 0x7fffffff, 0x00000001 ), # most neg < most pos = true

    # Test boundary values
    gen_rr_value_test( "slt", 0x7fffffff, 0x80000000, 0x00000000 ), # most pos < most neg = false
    gen_rr_value_test( "slt", 0x80000000, 0x80000000, 0x00000000 ), # most neg < most neg = false
    gen_rr_value_test( "slt", 0x7fffffff, 0x7fffffff, 0x00000000 ), # most pos < most pos = false

    # Test negative number comparisons
    gen_rr_value_test( "slt", 0xfffffffe, 0xffffffff, 0x00000001 ), # -2 < -1 = true
    gen_rr_value_test( "slt", 0xffffffff, 0xfffffffe, 0x00000000 ), # -1 < -2 = false
    gen_rr_value_test( "slt", 0x80000001, 0x80000000, 0x00000000 ), # -2147483647 < -2147483648 = false

    # Additional edge cases
    gen_rr_value_test( "slt", 0x00000000, 0x7fffffff, 0x00000001 ), # 0 < max_pos = true
    gen_rr_value_test( "slt", 0x7fffffff, 0x00000000, 0x00000000 ), # max_pos < 0 = false
    gen_rr_value_test( "slt", 0x80000000, 0x00000000, 0x00000001 ), # min_neg < 0 = true

    # Test with same magnitude, different signs
    gen_rr_value_test( "slt", 0x80000001, 0x7fffffff, 0x00000001 ), # -max_pos < max_pos = true
    gen_rr_value_test( "slt", 0x7fffffff, 0x80000001, 0x00000000 ), # max_pos < -max_pos = false

  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():
  asm_code = []
  for i in range(100):
    src0 = b32( random.randint(0,0xffffffff) )
    src1 = b32( random.randint(0,0xffffffff) )
    # SLT performs signed comparison, so convert to signed for comparison
    src0_signed = src0.int()
    src1_signed = src1.int()
    result = 1 if src0_signed < src1_signed else 0
    asm_code.append( gen_rr_value_test( "slt", src0.uint(), src1.uint(), result ) )
  return asm_code