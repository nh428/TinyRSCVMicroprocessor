#=========================================================================
# sll
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """
    csrr x1, mngr2proc < 0x00000001
    csrr x2, mngr2proc < 4
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    sll x3, x1, x2
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    csrw proc2mngr, x3 > 0x00000010
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
  """

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------

def gen_dest_dep_test():
  return [
    gen_rr_dest_dep_test( 5, "sll", 0x00000001, 1, 0x00000002 ),
    gen_rr_dest_dep_test( 4, "sll", 0x00000001, 2, 0x00000004 ),
    gen_rr_dest_dep_test( 3, "sll", 0x00000001, 3, 0x00000008 ),
    gen_rr_dest_dep_test( 2, "sll", 0x00000002, 1, 0x00000004 ),
    gen_rr_dest_dep_test( 1, "sll", 0x00000002, 2, 0x00000008 ),
    gen_rr_dest_dep_test( 0, "sll", 0x00000002, 3, 0x00000010 ),
  ]

#-------------------------------------------------------------------------
# gen_src0_dep_test
#-------------------------------------------------------------------------

def gen_src0_dep_test():
  return [
    gen_rr_src0_dep_test( 5, "sll", 0x00000001, 4, 0x00000010 ),
    gen_rr_src0_dep_test( 4, "sll", 0x00000003, 4, 0x00000030 ),
    gen_rr_src0_dep_test( 3, "sll", 0x00000007, 4, 0x00000070 ),
    gen_rr_src0_dep_test( 2, "sll", 0x0000000f, 4, 0x000000f0 ),
    gen_rr_src0_dep_test( 1, "sll", 0x000000ff, 4, 0x00000ff0 ),
    gen_rr_src0_dep_test( 0, "sll", 0x00001234, 4, 0x00012340 ),
  ]

#-------------------------------------------------------------------------
# gen_src1_dep_test
#-------------------------------------------------------------------------

def gen_src1_dep_test():
  return [
    gen_rr_src1_dep_test( 5, "sll", 0x00000001, 1, 0x00000002 ),
    gen_rr_src1_dep_test( 4, "sll", 0x00000001, 2, 0x00000004 ),
    gen_rr_src1_dep_test( 3, "sll", 0x00000001, 3, 0x00000008 ),
    gen_rr_src1_dep_test( 2, "sll", 0x00000001, 8, 0x00000100 ),
    gen_rr_src1_dep_test( 1, "sll", 0x00000001, 16, 0x00010000 ),
    gen_rr_src1_dep_test( 0, "sll", 0x00000001, 31, 0x80000000 ),
  ]

#-------------------------------------------------------------------------
# gen_srcs_dep_test
#-------------------------------------------------------------------------

def gen_srcs_dep_test():
  return [
    gen_rr_srcs_dep_test( 5, "sll", 0x00000001, 1, 0x00000002 ),
    gen_rr_srcs_dep_test( 4, "sll", 0x00000002, 2, 0x00000008 ),
    gen_rr_srcs_dep_test( 3, "sll", 0x00000004, 3, 0x00000020 ),
    gen_rr_srcs_dep_test( 2, "sll", 0x00000008, 4, 0x00000080 ),
    gen_rr_srcs_dep_test( 1, "sll", 0x00000010, 5, 0x00000200 ),
    gen_rr_srcs_dep_test( 0, "sll", 0x00000020, 6, 0x00000800 ),
  ]

#-------------------------------------------------------------------------
# gen_srcs_dest_test
#-------------------------------------------------------------------------

def gen_srcs_dest_test():
  return [
    gen_rr_src0_eq_dest_test( "sll", 0x00000001, 1, 0x00000002 ),
    gen_rr_src1_eq_dest_test( "sll", 0x00000001, 4, 0x00000010 ),
    gen_rr_src0_eq_src1_test( "sll", 8, 0x00000800 ),  # 8 << 8 = 2048
    gen_rr_srcs_eq_dest_test( "sll", 4, 0x00000040 ),  # 4 << 4 = 64
  ]

#-------------------------------------------------------------------------
# gen_value_test
#-------------------------------------------------------------------------

def gen_value_test():
  return [

    # Test basic zero shift
    gen_rr_value_test( "sll", 0x00000001, 0, 0x00000001 ),
    gen_rr_value_test( "sll", 0x12345678, 0, 0x12345678 ),
    gen_rr_value_test( "sll", 0x00000000, 0, 0x00000000 ),

    # Test single bit shifts
    gen_rr_value_test( "sll", 0x00000001, 1, 0x00000002 ),
    gen_rr_value_test( "sll", 0x40000000, 1, 0x80000000 ),
    gen_rr_value_test( "sll", 0x80000000, 1, 0x00000000 ), # overflow wraps to 0

    # Test multi-bit shifts
    gen_rr_value_test( "sll", 0x00000001, 4, 0x00000010 ),
    gen_rr_value_test( "sll", 0x00000001, 8, 0x00000100 ),
    gen_rr_value_test( "sll", 0x00000001, 16, 0x00010000 ),

    # Test with various source values
    gen_rr_value_test( "sll", 0x000000ff, 8, 0x0000ff00 ),
    gen_rr_value_test( "sll", 0x0000ffff, 8, 0x00ffff00 ),
    gen_rr_value_test( "sll", 0x00ffffff, 8, 0xffffff00 ),

    # Test maximum shift (31 bits)
    gen_rr_value_test( "sll", 0x00000001, 31, 0x80000000 ), # 1 << 31 = sign bit
    gen_rr_value_test( "sll", 0x00000002, 31, 0x00000000 ), # 2 << 31 = overflow
    gen_rr_value_test( "sll", 0x7fffffff, 31, 0x80000000 ), # max positive << 31

    # Test shifts that use only lower 5 bits of shift amount (RISC-V spec)
    gen_rr_value_test( "sll", 0x00000001, 32, 0x00000001 ), # 32 & 0x1f = 0
    gen_rr_value_test( "sll", 0x00000001, 33, 0x00000002 ), # 33 & 0x1f = 1
    gen_rr_value_test( "sll", 0x00000001, 36, 0x00000010 ), # 36 & 0x1f = 4

    # Test overflow behavior
    gen_rr_value_test( "sll", 0x80000000, 1, 0x00000000 ), # MSB shifts out
    gen_rr_value_test( "sll", 0xc0000000, 1, 0x80000000 ), # Two MSBs, one shifts out
    gen_rr_value_test( "sll", 0xffffffff, 1, 0xfffffffe ), # All bits shift left

    # Test various patterns
    gen_rr_value_test( "sll", 0x12345678, 4, 0x23456780 ),
    gen_rr_value_test( "sll", 0x87654321, 4, 0x76543210 ),
    gen_rr_value_test( "sll", 0xaaaaaaaa, 1, 0x55555554 ), # Alternating pattern

    # Test with small values that will create specific patterns
    gen_rr_value_test( "sll", 0x00000003, 1, 0x00000006 ), # 3 << 1 = 6
    gen_rr_value_test( "sll", 0x00000003, 2, 0x0000000c ), # 3 << 2 = 12
    gen_rr_value_test( "sll", 0x00000003, 30, 0xc0000000 ), # 3 << 30

    # Test edge cases that show bit loss
    gen_rr_value_test( "sll", 0x80000001, 1, 0x00000002 ), # MSB lost, LSB shifted
    gen_rr_value_test( "sll", 0x40000001, 2, 0x00000004 ), # Multiple bits lost
    gen_rr_value_test( "sll", 0x0000ffff, 16, 0xffff0000 ), # Lower half to upper

    # Additional comprehensive tests
    gen_rr_value_test( "sll", 0x00000001, 1, 0x00000002 ),
    gen_rr_value_test( "sll", 0x00000002, 1, 0x00000004 ),
    gen_rr_value_test( "sll", 0x00001000, 4, 0x00010000 ),

    # Test with negative numbers (treated as unsigned for shifting)
    gen_rr_value_test( "sll", 0xffffffff, 4, 0xfffffff0 ),
    gen_rr_value_test( "sll", 0xffff0000, 4, 0xfff00000 ),
    gen_rr_value_test( "sll", 0xff000000, 4, 0xf0000000 ),

  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():
  asm_code = []
  for i in range(100):
    src0 = b32( random.randint(0,0xffffffff) )
    # Shift amount is only lower 5 bits (0-31 for RISC-V)
    shift_amt = random.randint(0, 63)  # Test with larger values to verify masking
    effective_shift = shift_amt & 0x1f  # Only lower 5 bits matter
    
    # Perform logical left shift with proper 32-bit wrapping
    result = (src0.uint() << effective_shift) & 0xffffffff
    
    asm_code.append( gen_rr_value_test( "sll", src0.uint(), shift_amt, result ) )
  return asm_code