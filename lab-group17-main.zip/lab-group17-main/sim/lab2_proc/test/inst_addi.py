#=========================================================================
# addi
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """
    csrr x1, mngr2proc < 5
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    addi x3, x1, 4
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    csrw proc2mngr, x3 > 9
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
  """

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------

def gen_dest_dep_test():
  return [
    gen_rimm_dest_dep_test( 5, "addi", 1, 1, 2 ),
    gen_rimm_dest_dep_test( 4, "addi", 2, 1, 3 ),
    gen_rimm_dest_dep_test( 3, "addi", 3, 1, 4 ),
    gen_rimm_dest_dep_test( 2, "addi", 4, 1, 5 ),
    gen_rimm_dest_dep_test( 1, "addi", 5, 1, 6 ),
    gen_rimm_dest_dep_test( 0, "addi", 6, 1, 7 ),
  ]

#-------------------------------------------------------------------------
# gen_src_dep_test
#-------------------------------------------------------------------------

def gen_src_dep_test():
  return [
    gen_rimm_src_dep_test( 5, "addi",  7, 1,  8 ),
    gen_rimm_src_dep_test( 4, "addi",  8, 1,  9 ),
    gen_rimm_src_dep_test( 3, "addi",  9, 1, 10 ),
    gen_rimm_src_dep_test( 2, "addi", 10, 1, 11 ),
    gen_rimm_src_dep_test( 1, "addi", 11, 1, 12 ),
    gen_rimm_src_dep_test( 0, "addi", 12, 1, 13 ),
  ]

#-------------------------------------------------------------------------
# gen_src_eq_dest_test
#-------------------------------------------------------------------------

def gen_src_eq_dest_test():
  return [
    gen_rimm_src_eq_dest_test( "addi", 25, 1, 26 ),
    gen_rimm_src_eq_dest_test( "addi", 26, -1, 25 ),
    gen_rimm_src_eq_dest_test( "addi", 27, 0, 27 ),
  ]

#-------------------------------------------------------------------------
# gen_value_test
#-------------------------------------------------------------------------

def gen_value_test():
  return [

    # Test basic zero and small positive values
    gen_rimm_value_test( "addi", 0x00000000, 0x000, 0x00000000 ),
    gen_rimm_value_test( "addi", 0x00000001, 0x001, 0x00000002 ),
    gen_rimm_value_test( "addi", 0x00000003, 0x007, 0x0000000a ),

    # Test with negative immediates
    gen_rimm_value_test( "addi", 0x00000000, 0x800, 0xfffff800 ), # -2048
    gen_rimm_value_test( "addi", 0x80000000, 0x000, 0x80000000 ),
    gen_rimm_value_test( "addi", 0x80000000, 0x800, 0x7ffff800 ), # overflow

    # Test with positive max immediate (2047)
    gen_rimm_value_test( "addi", 0x00000000, 0x7ff, 0x000007ff ),
    gen_rimm_value_test( "addi", 0x7fffffff, 0x000, 0x7fffffff ),
    gen_rimm_value_test( "addi", 0x7fffffff, 0x7ff, 0x800007fe ), # overflow

    # Test edge cases with large negative immediate
    gen_rimm_value_test( "addi", 0x80000000, 0x7ff, 0x800007ff ),
    gen_rimm_value_test( "addi", 0x7fffffff, 0x800, 0x7ffff7ff ),

    # Test with -1 immediate (0xfff)
    gen_rimm_value_test( "addi", 0x00000000, 0xfff, 0xffffffff ),
    gen_rimm_value_test( "addi", 0xffffffff, 0x001, 0x00000000 ), # wrap around
    gen_rimm_value_test( "addi", 0xffffffff, 0xfff, 0xfffffffe ), # -1 + (-1)

    # Additional boundary tests
    gen_rimm_value_test( "addi", 0x00000001, 0xfff, 0x00000000 ), # 1 + (-1)
    gen_rimm_value_test( "addi", 0x000007ff, 0x001, 0x00000800 ), # 2047 + 1
    gen_rimm_value_test( "addi", 0xfffff800, 0x7ff, 0xffffffff ), # -2048 + 2047

    # Test zero immediate
    gen_rimm_value_test( "addi", 0x12345678, 0x000, 0x12345678 ),
    gen_rimm_value_test( "addi", 0xfedcba98, 0x000, 0xfedcba98 ),

    # Test small negative immediates
    gen_rimm_value_test( "addi", 0x00000010, 0xfff, 0x0000000f ), # 16 + (-1)
    gen_rimm_value_test( "addi", 0x00000010, 0xffe, 0x0000000e ), # 16 + (-2)
    gen_rimm_value_test( "addi", 0x00000010, 0xff0, 0x00000000 ), # 16 + (-16)

  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():
  asm_code = []
  for i in range(100):
    src = b32( random.randint(0,0xffffffff) )
    # Generate 12-bit signed immediate (-2048 to 2047)
    imm_val = random.randint(-2048, 2047)
    # Convert to 12-bit representation for encoding
    if imm_val < 0:
      imm = (imm_val + 4096) & 0xfff  # Two's complement in 12 bits
    else:
      imm = imm_val & 0xfff
    # Calculate expected result
    dest = src + b32(imm_val)
    asm_code.append( gen_rimm_value_test( "addi", src.uint(), imm, dest.uint() ) )
  return asm_code