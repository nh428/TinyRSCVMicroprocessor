#=========================================================================
# sw
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """
    csrr x1, mngr2proc < 0x00002000
    csrr x2, mngr2proc < 0xdeadbeef
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    sw   x2, 0(x1)
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    lw   x3, 0(x1)
    csrw proc2mngr, x3 > 0xdeadbeef

    .data
    .word 0x01020304
  """

#-------------------------------------------------------------------------
# gen_st_template
#-------------------------------------------------------------------------
# Template for store instructions. We first write the base register and
# the source register before executing the instruction under test. We
# parameterize the number of nops after writing registers and the
# instruction under test to enable testing various bypass paths.

def gen_st_template(
  num_nops_base, num_nops_src, num_nops_dest,
  reg_base, reg_src,
  inst, offset, base, src
):
  return """

    # Move base value into register
    csrr {reg_base}, mngr2proc < {base}
    {nops_base}

    # Move src value into register
    csrr {reg_src}, mngr2proc < {src}
    {nops_src}

    # Instruction under test
    {inst} {reg_src}, {offset}({reg_base})
    {nops_dest}

    # Load back the stored value to verify
    lw x3, {offset}({reg_base})

    # Check the result
    csrw proc2mngr, x3 > {src}

  """.format(
    nops_base = gen_nops(num_nops_base),
    nops_src = gen_nops(num_nops_src),
    nops_dest = gen_nops(num_nops_dest),
    **locals()
  )

#-------------------------------------------------------------------------
# gen_st_dest_dep_test
#-------------------------------------------------------------------------
# Test the destination (memory) bypass path by varying how many nops are
# inserted between the store instruction and the load that verifies it.

def gen_st_dest_dep_test( num_nops, inst, base, src ):
  return gen_st_template( 8, 0, num_nops, "x1", "x2", inst, 0, base, src )

#-------------------------------------------------------------------------
# gen_st_base_dep_test
#-------------------------------------------------------------------------
# Test the base register bypass paths by varying how many nops are
# inserted between writing the base register and reading this register in
# the instruction under test.

def gen_st_base_dep_test( num_nops, inst, base, src ):
  return gen_st_template( num_nops, 8-num_nops, 0, "x1", "x2", inst, 0, base, src )

#-------------------------------------------------------------------------
# gen_st_src_dep_test
#-------------------------------------------------------------------------
# Test the source register bypass paths by varying how many nops are
# inserted between writing the source register and reading this register in
# the instruction under test.

def gen_st_src_dep_test( num_nops, inst, base, src ):
  return gen_st_template( 8-num_nops, num_nops, 0, "x1", "x2", inst, 0, base, src )

#-------------------------------------------------------------------------
# gen_st_base_eq_src_test
#-------------------------------------------------------------------------
# Test situation where the base register specifier is the same as the
# source register specifier.

def gen_st_base_eq_src_test( inst, base, src ):
  return gen_st_template( 0, 0, 0, "x1", "x1", inst, 0, base, src )

#-------------------------------------------------------------------------
# gen_st_value_test
#-------------------------------------------------------------------------
# Test the actual operation of a store instruction under test.
# We assume that bypassing has already been tested.

def gen_st_value_test( inst, offset, base, src ):
  return gen_st_template( 0, 0, 0, "x1", "x2", inst, offset, base, src )

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------

def gen_dest_dep_test():
  return [

    gen_st_dest_dep_test( 5, "sw", 0x2000, 0x00010203 ),
    gen_st_dest_dep_test( 4, "sw", 0x2004, 0x04050607 ),
    gen_st_dest_dep_test( 3, "sw", 0x2008, 0x08090a0b ),
    gen_st_dest_dep_test( 2, "sw", 0x200c, 0x0c0d0e0f ),
    gen_st_dest_dep_test( 1, "sw", 0x2010, 0x10111213 ),
    gen_st_dest_dep_test( 0, "sw", 0x2014, 0x14151617 ),

    gen_word_data([
      0x00000000,
      0x00000000,
      0x00000000,
      0x00000000,
      0x00000000,
      0x00000000,
    ])

  ]

#-------------------------------------------------------------------------
# gen_base_dep_test
#-------------------------------------------------------------------------

def gen_base_dep_test():
  return [

    gen_st_base_dep_test( 5, "sw", 0x2000, 0x00010203 ),
    gen_st_base_dep_test( 4, "sw", 0x2004, 0x04050607 ),
    gen_st_base_dep_test( 3, "sw", 0x2008, 0x08090a0b ),
    gen_st_base_dep_test( 2, "sw", 0x200c, 0x0c0d0e0f ),
    gen_st_base_dep_test( 1, "sw", 0x2010, 0x10111213 ),
    gen_st_base_dep_test( 0, "sw", 0x2014, 0x14151617 ),

    gen_word_data([
      0x00000000,
      0x00000000,
      0x00000000,
      0x00000000,
      0x00000000,
      0x00000000,
    ])

  ]

#-------------------------------------------------------------------------
# gen_src_dep_test
#-------------------------------------------------------------------------

def gen_src_dep_test():
  return [

    gen_st_src_dep_test( 5, "sw", 0x2000, 0x00010203 ),
    gen_st_src_dep_test( 4, "sw", 0x2004, 0x04050607 ),
    gen_st_src_dep_test( 3, "sw", 0x2008, 0x08090a0b ),
    gen_st_src_dep_test( 2, "sw", 0x200c, 0x0c0d0e0f ),
    gen_st_src_dep_test( 1, "sw", 0x2010, 0x10111213 ),
    gen_st_src_dep_test( 0, "sw", 0x2014, 0x14151617 ),

    gen_word_data([
      0x00000000,
      0x00000000,
      0x00000000,
      0x00000000,
      0x00000000,
      0x00000000,
    ])

  ]

#-------------------------------------------------------------------------
# gen_srcs_dest_test
#-------------------------------------------------------------------------

def gen_srcs_dest_test():
  return [
    gen_st_base_eq_src_test( "sw", 0x01020304, 0x2000 ),
    gen_word_data([ 0x00000000 ])
  ]

#-------------------------------------------------------------------------
# gen_addr_test
#-------------------------------------------------------------------------

def gen_addr_test():
  return [

    # Test positive offsets

    gen_st_value_test( "sw",   0, 0x00002000, 0xdeadbeef ),
    gen_st_value_test( "sw",   4, 0x00002000, 0x00010203 ),
    gen_st_value_test( "sw",   8, 0x00002000, 0x04050607 ),
    gen_st_value_test( "sw",  12, 0x00002000, 0x08090a0b ),
    gen_st_value_test( "sw",  16, 0x00002000, 0x0c0d0e0f ),
    gen_st_value_test( "sw",  20, 0x00002000, 0xcafecafe ),

    # Test negative offsets

    gen_st_value_test( "sw", -20, 0x00002014, 0xdeadbeef ),
    gen_st_value_test( "sw", -16, 0x00002014, 0x00010203 ),
    gen_st_value_test( "sw", -12, 0x00002014, 0x04050607 ),
    gen_st_value_test( "sw",  -8, 0x00002014, 0x08090a0b ),
    gen_st_value_test( "sw",  -4, 0x00002014, 0x0c0d0e0f ),
    gen_st_value_test( "sw",   0, 0x00002014, 0xcafecafe ),

    # Test positive offset with unaligned base

    gen_st_value_test( "sw",   1, 0x00001fff, 0xdeadbeef ),
    gen_st_value_test( "sw",   5, 0x00001fff, 0x00010203 ),
    gen_st_value_test( "sw",   9, 0x00001fff, 0x04050607 ),
    gen_st_value_test( "sw",  13, 0x00001fff, 0x08090a0b ),
    gen_st_value_test( "sw",  17, 0x00001fff, 0x0c0d0e0f ),
    gen_st_value_test( "sw",  21, 0x00001fff, 0xcafecafe ),

    # Test negative offset with unaligned base

    gen_st_value_test( "sw", -21, 0x00002015, 0xdeadbeef ),
    gen_st_value_test( "sw", -17, 0x00002015, 0x00010203 ),
    gen_st_value_test( "sw", -13, 0x00002015, 0x04050607 ),
    gen_st_value_test( "sw",  -9, 0x00002015, 0x08090a0b ),
    gen_st_value_test( "sw",  -5, 0x00002015, 0x0c0d0e0f ),
    gen_st_value_test( "sw",  -1, 0x00002015, 0xcafecafe ),

    gen_word_data([
      0x00000000,
      0x00000000,
      0x00000000,
      0x00000000,
      0x00000000,
      0x00000000,
    ])

  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():

  # Generate some random data values to store

  data_values = []
  for i in range(100):
    data_values.append( random.randint(0,0xffffffff) )

  # Generate random store operations

  asm_code = []
  for i in range(100):

    a = random.randint(0,99)
    b = random.randint(0,99)

    base   = 0x2000 + (4*b)
    offset = 4*(a - b)
    src_value = data_values[a]

    asm_code.append( gen_st_value_test( "sw", offset, base, src_value ) )

  # Initialize memory with zeros
  asm_code.append( gen_word_data( [0] * 100 ) )
  return asm_code