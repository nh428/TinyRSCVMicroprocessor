#=========================================================================
# slli
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """
    csrr x1, mngr2proc < 0x00000001
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    slli x3, x1, 4
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    csrw proc2mngr, x3 > 0x00000010
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
  """

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------

def gen_dest_dep_test():
  return [
    gen_rimm_dest_dep_test( 5, "slli", 0x00000001, 3, 0x00000008 ),
    gen_rimm_dest_dep_test( 4, "slli", 0x00000007, 2, 0x0000001c ),
    gen_rimm_dest_dep_test( 3, "slli", 0x0000000f, 4, 0x000000f0 ),
    gen_rimm_dest_dep_test( 2, "slli", 0x12345678, 8, 0x34567800 ),
    gen_rimm_dest_dep_test( 1, "slli", 0x87654321, 12, 0x54321000 ),
    gen_rimm_dest_dep_test( 0, "slli", 0xfedcba98, 16, 0xba980000 ),
  ]

#-------------------------------------------------------------------------
# gen_src_dep_test
#-------------------------------------------------------------------------

def gen_src_dep_test():
  return [
    gen_rimm_src_dep_test( 5, "slli", 0x12345678, 4, 0x23456780 ),
    gen_rimm_src_dep_test( 4, "slli", 0x87654321, 4, 0x76543210 ),
    gen_rimm_src_dep_test( 3, "slli", 0x11111111, 8, 0x11111100 ),
    gen_rimm_src_dep_test( 2, "slli", 0x88888888, 8, 0x88888800 ),
    gen_rimm_src_dep_test( 1, "slli", 0x0000ffff, 4, 0x000ffff0 ),
    gen_rimm_src_dep_test( 0, "slli", 0xffff0000, 4, 0xfff00000 ),
  ]

#-------------------------------------------------------------------------
# gen_src_eq_dest_test
#-------------------------------------------------------------------------

def gen_src_eq_dest_test():
  return [
    gen_rimm_src_eq_dest_test( "slli", 0x12345678, 4, 0x23456780 ),
    gen_rimm_src_eq_dest_test( "slli", 0x87654321, 8, 0x54321000 ),
    gen_rimm_src_eq_dest_test( "slli", 0x00000001, 31, 0x80000000 ),
  ]

#-------------------------------------------------------------------------
# gen_value_test
#-------------------------------------------------------------------------

def gen_value_test():
  return [

    # Test shift by 0 (no change)
    gen_rimm_value_test( "slli", 0x12345678, 0x000, 0x12345678 ),
    gen_rimm_value_test( "slli", 0x87654321, 0x000, 0x87654321 ),
    gen_rimm_value_test( "slli", 0x00000000, 0x000, 0x00000000 ),
    gen_rimm_value_test( "slli", 0xffffffff, 0x000, 0xffffffff ),

    # Test shift by 1
    gen_rimm_value_test( "slli", 0x80000000, 0x001, 0x00000000 ), # MSB shifts out
    gen_rimm_value_test( "slli", 0x40000000, 0x001, 0x80000000 ), # 0x4... becomes 0x8...
    gen_rimm_value_test( "slli", 0x00000002, 0x001, 0x00000004 ),
    gen_rimm_value_test( "slli", 0x00000001, 0x001, 0x00000002 ),

    # Test various shift amounts with different patterns
    gen_rimm_value_test( "slli", 0x12345678, 0x004, 0x23456780 ), # Shift by 4
    gen_rimm_value_test( "slli", 0x12345678, 0x008, 0x34567800 ), # Shift by 8
    gen_rimm_value_test( "slli", 0x12345678, 0x010, 0x56780000 ), # Shift by 16
    gen_rimm_value_test( "slli", 0x12345678, 0x01f, 0x00000000 ), # Shift by 31

    # Test with small values
    gen_rimm_value_test( "slli", 0x00000001, 0x004, 0x00000010 ), # 1 << 4 = 16
    gen_rimm_value_test( "slli", 0x00000001, 0x008, 0x00000100 ), # 1 << 8 = 256
    gen_rimm_value_test( "slli", 0x00000001, 0x010, 0x00010000 ), # 1 << 16 = 65536
    gen_rimm_value_test( "slli", 0x00000001, 0x01f, 0x80000000 ), # 1 << 31 = most negative

    # Test with alternating bit patterns
    gen_rimm_value_test( "slli", 0xaaaaaaaa, 0x001, 0x55555554 ), # Alternating pattern << 1
    gen_rimm_value_test( "slli", 0x55555555, 0x001, 0xaaaaaaaa ), # Alternating pattern << 1
    gen_rimm_value_test( "slli", 0xaaaaaaaa, 0x004, 0xaaaaaaa0 ),
    gen_rimm_value_test( "slli", 0x55555555, 0x004, 0x55555550 ),

    # Test with powers of 2
    gen_rimm_value_test( "slli", 0x00000001, 0x00a, 0x00000400 ), # 1 << 10 = 1024
    gen_rimm_value_test( "slli", 0x00000001, 0x014, 0x00100000 ), # 1 << 20 = 1M
    gen_rimm_value_test( "slli", 0x00000002, 0x00f, 0x00010000 ), # 2 << 15 = 65536

    # Test edge cases where bits get shifted out
    gen_rimm_value_test( "slli", 0xffffffff, 0x001, 0xfffffffe ), # All 1s << 1
    gen_rimm_value_test( "slli", 0xffffffff, 0x008, 0xffffff00 ), # All 1s << 8
    gen_rimm_value_test( "slli", 0xffffffff, 0x010, 0xffff0000 ), # All 1s << 16
    gen_rimm_value_test( "slli", 0xffffffff, 0x01f, 0x80000000 ), # All 1s << 31

    # Test with high bits set
    gen_rimm_value_test( "slli", 0xf0000000, 0x001, 0xe0000000 ), # High nibble << 1
    gen_rimm_value_test( "slli", 0xf0000000, 0x004, 0x00000000 ), # High nibble shifts out
    gen_rimm_value_test( "slli", 0xff000000, 0x008, 0x00000000 ), # High byte shifts out

    # Test with low bits set
    gen_rimm_value_test( "slli", 0x0000000f, 0x004, 0x000000f0 ), # Low nibble << 4
    gen_rimm_value_test( "slli", 0x000000ff, 0x008, 0x0000ff00 ), # Low byte << 8
    gen_rimm_value_test( "slli", 0x0000ffff, 0x010, 0xffff0000 ), # Low word << 16

    # Test boundary cases with maximum shift amount (31)
    gen_rimm_value_test( "slli", 0x00000002, 0x01e, 0x80000000 ), # 2 << 30 = MSB set
    gen_rimm_value_test( "slli", 0x00000003, 0x01e, 0xc0000000 ), # 3 << 30
    gen_rimm_value_test( "slli", 0x00000004, 0x01d, 0x80000000 ), # 4 << 29

    # Test zero cases
    gen_rimm_value_test( "slli", 0x00000000, 0x01f, 0x00000000 ), # 0 shifted = 0
    gen_rimm_value_test( "slli", 0x00000000, 0x001, 0x00000000 ), # 0 shifted = 0

    # Test cases where upper bits are lost
    gen_rimm_value_test( "slli", 0x80000001, 0x001, 0x00000002 ), # MSB lost, LSB shifted
    gen_rimm_value_test( "slli", 0xc0000000, 0x002, 0x00000000 ), # Top 2 bits lost
    gen_rimm_value_test( "slli", 0xf0000000, 0x004, 0x00000000 ), # Top nibble lost

    # Test with specific bit patterns
    gen_rimm_value_test( "slli", 0x01010101, 0x008, 0x01010100 ), # Repeated byte pattern
    gen_rimm_value_test( "slli", 0x11111111, 0x004, 0x11111110 ), # Repeated nibble pattern
    gen_rimm_value_test( "slli", 0x33333333, 0x002, 0xcccccccc ), # 2-bit pattern repetition

    # Additional edge cases
    gen_rimm_value_test( "slli", 0x7fffffff, 0x001, 0xfffffffe ), # Max positive << 1
    gen_rimm_value_test( "slli", 0x80000000, 0x001, 0x00000000 ), # Min negative << 1

  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():
  asm_code = []
  for i in range(100):
    src = b32( random.randint(0,0xffffffff) )
    # For SLLI, the shift amount must be 0-31 (5 bits)
    shift_amt = random.randint(0, 31)
    
    # SLLI performs logical left shift
    # Shift left and mask to 32 bits (bits that shift out are lost)
    result = (src.uint() << shift_amt) & 0xffffffff
    
    asm_code.append( gen_rimm_value_test( "slli", src.uint(), shift_amt, result ) )
  return asm_code