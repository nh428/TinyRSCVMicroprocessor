#=========================================================================
# srai
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """
    csrr x1, mngr2proc < 0x80000000
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    srai x3, x1, 1
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    csrw proc2mngr, x3 > 0xc0000000
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
  """

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------

def gen_dest_dep_test():
  return [
    gen_rimm_dest_dep_test( 5, "srai", 0x80000008, 3, 0xf0000001 ),
    gen_rimm_dest_dep_test( 4, "srai", 0x40000000, 2, 0x10000000 ),
    gen_rimm_dest_dep_test( 3, "srai", 0x80000000, 4, 0xf8000000 ),
    gen_rimm_dest_dep_test( 2, "srai", 0x12345678, 8, 0x00123456 ),
    gen_rimm_dest_dep_test( 1, "srai", 0x87654321, 12, 0xfff87654 ),
    gen_rimm_dest_dep_test( 0, "srai", 0xfedcba98, 16, 0xfffffedc ),
  ]

#-------------------------------------------------------------------------
# gen_src_dep_test
#-------------------------------------------------------------------------

def gen_src_dep_test():
  return [
    gen_rimm_src_dep_test( 5, "srai", 0x12345678, 4, 0x01234567 ),
    gen_rimm_src_dep_test( 4, "srai", 0x87654321, 4, 0xf8765432 ),
    gen_rimm_src_dep_test( 3, "srai", 0x11111111, 8, 0x00111111 ),
    gen_rimm_src_dep_test( 2, "srai", 0x88888888, 8, 0xff888888 ),
    gen_rimm_src_dep_test( 1, "srai", 0x0000ffff, 4, 0x00000fff ),
    gen_rimm_src_dep_test( 0, "srai", 0xffff0000, 4, 0xfffff000 ),
  ]

#-------------------------------------------------------------------------
# gen_src_eq_dest_test
#-------------------------------------------------------------------------

def gen_src_eq_dest_test():
  return [
    gen_rimm_src_eq_dest_test( "srai", 0x12345678, 4, 0x01234567 ),
    gen_rimm_src_eq_dest_test( "srai", 0x87654321, 8, 0xff876543 ),
    gen_rimm_src_eq_dest_test( "srai", 0x80000000, 31, 0xffffffff ),
  ]

#-------------------------------------------------------------------------
# gen_value_test
#-------------------------------------------------------------------------

def gen_value_test():
  return [

    # Test shift by 0 (no change)
    gen_rimm_value_test( "srai", 0x12345678, 0x000, 0x12345678 ),
    gen_rimm_value_test( "srai", 0x87654321, 0x000, 0x87654321 ),
    gen_rimm_value_test( "srai", 0x00000000, 0x000, 0x00000000 ),
    gen_rimm_value_test( "srai", 0xffffffff, 0x000, 0xffffffff ),

    # Test shift by 1
    gen_rimm_value_test( "srai", 0x80000000, 0x001, 0xc0000000 ), # Sign extend
    gen_rimm_value_test( "srai", 0x40000000, 0x001, 0x20000000 ), # No sign extend
    gen_rimm_value_test( "srai", 0x00000002, 0x001, 0x00000001 ),
    gen_rimm_value_test( "srai", 0x00000001, 0x001, 0x00000000 ),

    # Test various shift amounts with positive numbers
    gen_rimm_value_test( "srai", 0x12345678, 0x004, 0x01234567 ), # Shift by 4
    gen_rimm_value_test( "srai", 0x12345678, 0x008, 0x00123456 ), # Shift by 8
    gen_rimm_value_test( "srai", 0x12345678, 0x010, 0x00001234 ), # Shift by 16
    gen_rimm_value_test( "srai", 0x12345678, 0x01f, 0x00000000 ), # Shift by 31

    # Test various shift amounts with negative numbers (sign extension)
    gen_rimm_value_test( "srai", 0x87654321, 0x004, 0xf8765432 ), # Shift by 4
    gen_rimm_value_test( "srai", 0x87654321, 0x008, 0xff876543 ), # Shift by 8
    gen_rimm_value_test( "srai", 0x87654321, 0x010, 0xffff8765 ), # Shift by 16
    gen_rimm_value_test( "srai", 0x87654321, 0x01f, 0xffffffff ), # Shift by 31

    # Test with most negative number
    gen_rimm_value_test( "srai", 0x80000000, 0x001, 0xc0000000 ), # Shift by 1
    gen_rimm_value_test( "srai", 0x80000000, 0x010, 0xffff8000 ), # Shift by 16
    gen_rimm_value_test( "srai", 0x80000000, 0x01f, 0xffffffff ), # Shift by 31

    # Test with -1 (all 1s)
    gen_rimm_value_test( "srai", 0xffffffff, 0x001, 0xffffffff ), # -1 >> 1 = -1
    gen_rimm_value_test( "srai", 0xffffffff, 0x010, 0xffffffff ), # -1 >> 16 = -1
    gen_rimm_value_test( "srai", 0xffffffff, 0x01f, 0xffffffff ), # -1 >> 31 = -1

    # Test with alternating bit patterns
    gen_rimm_value_test( "srai", 0xaaaaaaaa, 0x001, 0xd5555555 ), # Sign extends
    gen_rimm_value_test( "srai", 0x55555555, 0x001, 0x2aaaaaaa ), # No sign extend
    gen_rimm_value_test( "srai", 0xaaaaaaaa, 0x004, 0xfaaaaaaa ),
    gen_rimm_value_test( "srai", 0x55555555, 0x004, 0x05555555 ),

    # Test edge cases with small positive numbers
    gen_rimm_value_test( "srai", 0x00000001, 0x001, 0x00000000 ), # 1 >> 1 = 0
    gen_rimm_value_test( "srai", 0x00000007, 0x002, 0x00000001 ), # 7 >> 2 = 1
    gen_rimm_value_test( "srai", 0x0000000f, 0x004, 0x00000000 ), # 15 >> 4 = 0

    # Test with powers of 2
    gen_rimm_value_test( "srai", 0x00000100, 0x008, 0x00000001 ), # 256 >> 8 = 1
    gen_rimm_value_test( "srai", 0x00001000, 0x00c, 0x00000001 ), # 4096 >> 12 = 1
    gen_rimm_value_test( "srai", 0x00010000, 0x010, 0x00000001 ), # 65536 >> 16 = 1

    # Test maximum positive number
    gen_rimm_value_test( "srai", 0x7fffffff, 0x001, 0x3fffffff ), # No sign extend
    gen_rimm_value_test( "srai", 0x7fffffff, 0x01f, 0x00000000 ), # Shift all bits out

    # Test various intermediate negative numbers
    gen_rimm_value_test( "srai", 0xffffff00, 0x008, 0xffffffff ), # -256 >> 8 = -1
    gen_rimm_value_test( "srai", 0xfffff000, 0x00c, 0xffffffff ), # -4096 >> 12 = -1
    gen_rimm_value_test( "srai", 0xffff0000, 0x010, 0xffffffff ), # -65536 >> 16 = -1

    # Test boundary cases with maximum shift amount (31)
    gen_rimm_value_test( "srai", 0x80000000, 0x01f, 0xffffffff ), # Most negative >> 31
    gen_rimm_value_test( "srai", 0x7fffffff, 0x01f, 0x00000000 ), # Most positive >> 31
    gen_rimm_value_test( "srai", 0x12345678, 0x01f, 0x00000000 ), # Positive >> 31

    # Additional boundary tests
    gen_rimm_value_test( "srai", 0x00000000, 0x01f, 0x00000000 ), # 0 shifted = 0
    gen_rimm_value_test( "srai", 0x80000001, 0x001, 0xc0000000 ), # Odd negative number
    gen_rimm_value_test( "srai", 0x80000002, 0x001, 0xc0000001 ), # Even negative number

  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():
  asm_code = []
  for i in range(100):
    src = b32( random.randint(0,0xffffffff) )
    # For SRAI, the shift amount must be 0-31 (5 bits)
    shift_amt = random.randint(0, 31)
    
    # SRAI performs arithmetic right shift
    src_signed = src.int()  # Interpret as signed
    if src_signed < 0:
      # For negative numbers, sign extend
      result = (src_signed >> shift_amt) & 0xffffffff
    else:
      # For positive numbers, normal right shift
      result = (src.uint() >> shift_amt) & 0xffffffff
    
    asm_code.append( gen_rimm_value_test( "srai", src.uint(), shift_amt, result ) )
  return asm_code