#=========================================================================
# lui
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """
    lui x1, 0x0001
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    csrw proc2mngr, x1 > 0x00001000
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
  """

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------

def gen_dest_dep_test():
  return [
    gen_imm_dest_dep_test( 5, "lui", 0x00001, 0x00001000 ),
    gen_imm_dest_dep_test( 4, "lui", 0x00002, 0x00002000 ),
    gen_imm_dest_dep_test( 3, "lui", 0x00003, 0x00003000 ),
    gen_imm_dest_dep_test( 2, "lui", 0x00004, 0x00004000 ),
    gen_imm_dest_dep_test( 1, "lui", 0x00005, 0x00005000 ),
    gen_imm_dest_dep_test( 0, "lui", 0x00006, 0x00006000 ),
  ]

#-------------------------------------------------------------------------
# gen_value_test
#-------------------------------------------------------------------------

def gen_value_test():
  return [

    # Test zero
    gen_imm_value_test( "lui", 0x00000, 0x00000000 ),

    # Test small positive values
    gen_imm_value_test( "lui", 0x00001, 0x00001000 ),
    gen_imm_value_test( "lui", 0x00002, 0x00002000 ),
    gen_imm_value_test( "lui", 0x00007, 0x00007000 ),
    gen_imm_value_test( "lui", 0x0000f, 0x0000f000 ),

    # Test powers of 2
    gen_imm_value_test( "lui", 0x00010, 0x00010000 ),
    gen_imm_value_test( "lui", 0x00020, 0x00020000 ),
    gen_imm_value_test( "lui", 0x00040, 0x00040000 ),
    gen_imm_value_test( "lui", 0x00080, 0x00080000 ),
    gen_imm_value_test( "lui", 0x00100, 0x00100000 ),
    gen_imm_value_test( "lui", 0x00200, 0x00200000 ),
    gen_imm_value_test( "lui", 0x00400, 0x00400000 ),
    gen_imm_value_test( "lui", 0x00800, 0x00800000 ),
    gen_imm_value_test( "lui", 0x01000, 0x01000000 ),
    gen_imm_value_test( "lui", 0x02000, 0x02000000 ),
    gen_imm_value_test( "lui", 0x04000, 0x04000000 ),
    gen_imm_value_test( "lui", 0x08000, 0x08000000 ),
    gen_imm_value_test( "lui", 0x10000, 0x10000000 ),
    gen_imm_value_test( "lui", 0x20000, 0x20000000 ),
    gen_imm_value_test( "lui", 0x40000, 0x40000000 ),
    gen_imm_value_test( "lui", 0x80000, 0x80000000 ),

    # Test boundary values
    gen_imm_value_test( "lui", 0x7ffff, 0x7ffff000 ),  # Maximum positive
    gen_imm_value_test( "lui", 0xfffff, 0xfffff000 ),  # Maximum value (sign-extended negative)

    # Test negative values (sign extension)
    gen_imm_value_test( "lui", 0x80000, 0x80000000 ),  # Most negative
    gen_imm_value_test( "lui", 0x80001, 0x80001000 ),
    gen_imm_value_test( "lui", 0xffffe, 0xffffe000 ),
    gen_imm_value_test( "lui", 0xfffff, 0xfffff000 ),

    # Test specific bit patterns
    gen_imm_value_test( "lui", 0x55555, 0x55555000 ),  # Alternating bits
    gen_imm_value_test( "lui", 0xaaaaa, 0xaaaaa000 ),  # Alternating bits
    gen_imm_value_test( "lui", 0x0f0f0, 0x0f0f0000 ),  # Nibble pattern
    gen_imm_value_test( "lui", 0xf0f0f, 0xf0f0f000 ),  # Nibble pattern

    # Test common values
    gen_imm_value_test( "lui", 0x12345, 0x12345000 ),
    gen_imm_value_test( "lui", 0xabcde, 0xabcde000 ),
    gen_imm_value_test( "lui", 0xfedcb, 0xfedcb000 ),

  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():
  asm_code = []
  for i in range(100):
    # Generate random 20-bit immediate value
    imm = random.randint(0, 0xfffff)
    # Calculate expected result: immediate shifted left by 12 bits
    result = (imm << 12) & 0xffffffff
    asm_code.append( gen_imm_value_test( "lui", imm, result ) )
  return asm_code