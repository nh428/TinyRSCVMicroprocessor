#=========================================================================
# jalr
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """

    # Use r3 to track the control flow pattern
    addi  x3, x0, 0           # 0x0200
                              #
    lui x1,      %hi[label_a] # 0x0204
    addi x1, x1, %lo[label_a] # 0x0208
                              #
    nop                       # 0x020c
    nop                       # 0x0210
    nop                       # 0x0214
    nop                       # 0x0218
    nop                       # 0x021c
    nop                       # 0x0220
    nop                       # 0x0224
    nop                       # 0x0228
                              #
    jalr  x31, x1, 0          # 0x022c
    addi  x3, x3, 0b01        # 0x0230

    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop

  label_a:
    addi  x3, x3, 0b10

    # Check the link address
    csrw  proc2mngr, x31 > 0x0230

    # Only the second bit should be set if jump was taken
    csrw  proc2mngr, x3  > 0b10

  """

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------
# Test the destination bypass path by varying how many nops are
# inserted between the JALR instruction and reading the destination
# register with a csrw instruction.

def gen_dest_dep_test():
  return [
    gen_jalr_dest_dep_test( 5 ),
    gen_jalr_dest_dep_test( 4 ),
    gen_jalr_dest_dep_test( 3 ),
    gen_jalr_dest_dep_test( 2 ),
    gen_jalr_dest_dep_test( 1 ),
    gen_jalr_dest_dep_test( 0 ),
  ]

#-------------------------------------------------------------------------
# gen_base_dep_test
#-------------------------------------------------------------------------
# Test the base register bypass path by varying how many nops are
# inserted between writing the base register and using it in JALR

def gen_base_dep_test():
  return [
    gen_jalr_base_dep_test( 5 ),
    gen_jalr_base_dep_test( 4 ),
    gen_jalr_base_dep_test( 3 ),
    gen_jalr_base_dep_test( 2 ),
    gen_jalr_base_dep_test( 1 ),
    gen_jalr_base_dep_test( 0 ),
  ]

#-------------------------------------------------------------------------
# gen_link_dep_test
#-------------------------------------------------------------------------
# Test using the link register immediately after the JALR with various
# numbers of nops to test bypass paths

def gen_link_dep_test():
  return [
    gen_jalr_link_dep_test( 5 ),
    gen_jalr_link_dep_test( 4 ),
    gen_jalr_link_dep_test( 3 ),
    gen_jalr_link_dep_test( 2 ),
    gen_jalr_link_dep_test( 1 ),
    gen_jalr_link_dep_test( 0 ),
  ]

#-------------------------------------------------------------------------
# gen_offset_test
#-------------------------------------------------------------------------
# Test various offset values with JALR

def gen_offset_test():
  return [
    # gen_jalr_positive_offset_test(),
    # gen_jalr_negative_offset_test(),
    # gen_jalr_zero_offset_test(),
    gen_jalr_large_offset_test(),
  ]

#-------------------------------------------------------------------------
# gen_link_register_test
#-------------------------------------------------------------------------
# Test different link registers including x0 (which discards the link)

def gen_link_register_test():
  return [
    gen_jalr_link_x0_test(),
    gen_jalr_link_x31_test(),
    gen_jalr_same_reg_test(),
  ]

#-------------------------------------------------------------------------
# gen_function_call_test
#-------------------------------------------------------------------------
# Test function call patterns with JALR

def gen_function_call_test():
  return [
    gen_jalr_function_call_test(),
    gen_jalr_function_return_test(),
    gen_jalr_nested_call_test(),
  ]

#-------------------------------------------------------------------------
# gen_edge_case_test
#-------------------------------------------------------------------------
# Test edge cases

def gen_edge_case_test():
  return [
    gen_jalr_base_eq_dest_test(),
    gen_jalr_computed_address_test(),
    gen_jalr_indirect_jump_test(),
  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():
  asm_code = []
  for i in range(10):
    # Generate simple random tests focusing on different offsets and targets
    offset = random.randint(-100, 100)
    control_pattern = random.randint(1, 15)
    asm_code.append( gen_jalr_simple_random_test( offset, control_pattern, i ) )
  return asm_code

# Helper functions for generating specific JALR tests

#-------------------------------------------------------------------------
# gen_jalr_dest_dep_test
#-------------------------------------------------------------------------
# Test destination dependency - can we read the link register after nops?

def gen_jalr_dest_dep_test( num_nops ):
  return f"""
    
    # Test destination dependency with {num_nops} nops
    addi  x3, x0, 0b01
    
    # Set up target address
    lui   x1, %hi[jalr_dest_target_{num_nops}]
    addi  x1, x1, %lo[jalr_dest_target_{num_nops}]
    
    jalr  x2, x1, 0
    addi  x3, x3, 0b10  # Should be skipped
    
  jalr_dest_target_{num_nops}:
    addi  x3, x3, 0b100
    {gen_nops(num_nops)}
    
    # Test that we can read the link register
    add   x4, x2, x0  # Copy link register 
    csrw  proc2mngr, x3 > 0b101  # Should have bits 0 and 2 set
    
  """

#-------------------------------------------------------------------------
# gen_jalr_base_dep_test
#-------------------------------------------------------------------------
# Test base register dependency

def gen_jalr_base_dep_test( num_nops ):
  return f"""
    
    # Test base register dependency with {num_nops} nops
    addi  x3, x0, 1
    
    # Write base register
    lui   x1, %hi[jalr_base_target_{num_nops}]
    addi  x1, x1, %lo[jalr_base_target_{num_nops}]
    {gen_nops(num_nops)}
    
    jalr  x2, x1, 0
    addi  x3, x3, 2  # Should be skipped
    
  jalr_base_target_{num_nops}:
    addi  x3, x3, 4
    csrw  proc2mngr, x3 > 5  # Should be 1 + 4 = 5
    
  """

#-------------------------------------------------------------------------
# gen_jalr_link_dep_test  
#-------------------------------------------------------------------------
# Test using the link register immediately after JALR

def gen_jalr_link_dep_test( num_nops ):
  return f"""
    
    # Test link register dependency with {num_nops} nops
    addi  x3, x0, 1
    
    # Set up target address
    lui   x1, %hi[jalr_link_target_{num_nops}]
    addi  x1, x1, %lo[jalr_link_target_{num_nops}]
    
    jalr  x2, x1, 0
    addi  x3, x3, 2  # Should be skipped
    
  jalr_link_target_{num_nops}:
    {gen_nops(num_nops)}
    # Use link register in arithmetic - test that bypassing works
    add   x4, x2, x3
    csrw  proc2mngr, x3 > 1  # Should still be 1
    
  """

#-------------------------------------------------------------------------
# gen_jalr_positive_offset_test
#-------------------------------------------------------------------------
# Test JALR with positive offset

def gen_jalr_positive_offset_test():
  return """
    
    # Test positive offset
    addi  x3, x0, 1
    
    # Set up base address (target - 8)
    lui   x1, %hi[jalr_pos_base]
    addi  x1, x1, %lo[jalr_pos_base]
    
    jalr  x2, x1, 8  # Jump to target with +8 offset
    addi  x3, x3, 2  # Should be skipped
    
  jalr_pos_base:
    nop  # base address points here
    nop
  jalr_pos_target:  # base + 8 points here
    addi  x3, x3, 4
    csrw  proc2mngr, x3 > 5  # Should be 1 + 4 = 5
    
  """

#-------------------------------------------------------------------------
# gen_jalr_negative_offset_test
#-------------------------------------------------------------------------
# Test JALR with negative offset

def gen_jalr_negative_offset_test():
  return """
    
    # Test negative offset
    addi  x3, x0, 1
    
    # Set up base address (target + 8)
    lui   x1, %hi[jalr_neg_base]
    addi  x1, x1, %lo[jalr_neg_base]
    addi  x2, x1, -12
    csrw  proc2mngr, x2 > 0x0000021c
    jalr  x2, x1, -12  # Jump to target with -12 offset
    addi  x3, x3, 2   # Should be skipped
    
  jalr_neg_target:  # base - 12 points here
    addi  x3, x3, 4
    csrw  proc2mngr, x3 > 5  # Should be 1 + 4 = 5
    jal   x0, jalr_neg_end
    
  jalr_neg_base:
    nop  # base address points here
    nop
    
  jalr_neg_end:
    nop
    
  """

#-------------------------------------------------------------------------
# gen_jalr_zero_offset_test
#-------------------------------------------------------------------------
# Test JALR with zero offset

def gen_jalr_zero_offset_test():
  return """
    
    # Test zero offset
    addi  x3, x0, 5
    
    # Set up target address
    lui   x1, %hi[jalr_zero_target]
    addi  x1, x1, %lo[jalr_zero_target]
    
    jalr  x2, x1, 0
    addi  x3, x3, 2  # Should be skipped
    
  jalr_zero_target:
    addi  x3, x3, 3
    csrw  proc2mngr, x3 > 8  # Should be 5 + 3 = 8
    
  """

#-------------------------------------------------------------------------
# gen_jalr_large_offset_test
#-------------------------------------------------------------------------
# Test JALR with large offset values

def gen_jalr_large_offset_test():
  return """
    
    # Test large positive and negative offsets
    addi  x3, x0, 1
    
    # Test with large positive offset (2047)
    lui   x1, %hi[jalr_large_target]
    addi  x1, x1, %lo[jalr_large_target]
    addi  x1, x1, -256  # Subtract 1024 from target address

    jalr  x2, x1, 256   # Add 1024 back to reach target
    addi  x3, x3, 2      # Should be skipped
    
  jalr_large_target:
    addi  x3, x3, 4
    
    # Test with large negative offset (-2048)
    lui   x1, %hi[jalr_large_target2]
    addi  x1, x1, %lo[jalr_large_target2]
    addi  x1, x1, 256   # Add 1024 to target address

    jalr  x2, x1, -256  # Subtract 1024 to reach target
    addi  x3, x3, 8      # Should be skipped
    
  jalr_large_target2:
    addi  x3, x3, 16
    csrw  proc2mngr, x3 > 21  # Should be 1 + 4 + 16 = 21
    
  """

#-------------------------------------------------------------------------
# gen_jalr_link_x0_test
#-------------------------------------------------------------------------
# Test JALR with x0 as destination (should discard return address)

def gen_jalr_link_x0_test():
  return """
    
    # Test JALR with x0 as link register
    addi  x3, x0, 0b01
    
    # Set up target address
    lui   x1, %hi[jalr_x0_target]
    addi  x1, x1, %lo[jalr_x0_target]
    
    jalr  x0, x1, 0
    addi  x3, x3, 0b10  # Should be skipped
    
  jalr_x0_target:
    addi  x3, x3, 0b100
    
    # x0 should always be zero
    csrw  proc2mngr, x0 > 0
    csrw  proc2mngr, x3 > 0b101
    
  """

#-------------------------------------------------------------------------
# gen_jalr_link_x31_test
#-------------------------------------------------------------------------
# Test JALR with x31 as destination

def gen_jalr_link_x31_test():
  return """
    
    # Test JALR with x31 as link register
    addi  x3, x0, 0b01
    
    # Set up target address
    lui   x1, %hi[jalr_x31_target]
    addi  x1, x1, %lo[jalr_x31_target]
    
    jalr  x31, x1, 0
    addi  x3, x3, 0b10  # Should be skipped
    
  jalr_x31_target:
    addi  x3, x3, 0b100
    
    # Just verify the control flow worked correctly
    csrw  proc2mngr, x3 > 0b101
    
  """

#-------------------------------------------------------------------------
# gen_jalr_same_reg_test
#-------------------------------------------------------------------------
# Test JALR where base register equals destination register

def gen_jalr_same_reg_test():
  return """
    
    # Test using same register for base and destination
    addi  x3, x0, 1
    
    # Set up target address in x1
    lui   x1, %hi[jalr_same_target]
    addi  x1, x1, %lo[jalr_same_target]
    
    # Use x1 as both base and destination
    jalr  x1, x1, 0
    addi  x3, x3, 2  # Should be skipped
    
  jalr_same_target:
    # x1 now contains the return address, not the target address
    # Just verify we reached this point
    addi  x4, x0, 42
    csrw  proc2mngr, x4 > 42
    
  """

#-------------------------------------------------------------------------
# gen_jalr_function_call_test
#-------------------------------------------------------------------------
# Test function call pattern with JALR

def gen_jalr_function_call_test():
  return """
    
    # Test function call pattern
    addi  x3, x0, 1
    
    # Call function
    lui   x1, %hi[jalr_function]
    addi  x1, x1, %lo[jalr_function]
    jalr  x31, x1, 0  # Call function, save return address in x31
    
    # Return point
    addi  x3, x3, 8
    csrw  proc2mngr, x3 > 15  # Should be 1 + 2 + 4 + 8 = 15 (not 8)
    jal   x0, jalr_func_end
    
  jalr_function:
    addi  x3, x3, 2
    addi  x3, x3, 4
    jalr  x0, x31, 0  # Return to caller
    
  jalr_func_end:
    nop
    
  """

#-------------------------------------------------------------------------
# gen_jalr_function_return_test
#-------------------------------------------------------------------------
# Test function return pattern with JALR

def gen_jalr_function_return_test():
  return """
    
    # Test return pattern - jalr x0, x1, 0 (standard return)
    addi  x3, x0, 1
    
    # Simulate a function call setup
    lui   x2, %hi[jalr_return_point]
    addi  x2, x2, %lo[jalr_return_point]
    
    jal   x0, jalr_ret_function
    
  jalr_return_point:
    addi  x3, x3, 8  # This should execute after return
    csrw  proc2mngr, x3 > 13  # Should be 1 + 4 + 8 = 13 (not 8)
    jal   x0, jalr_ret_end
    
  jalr_ret_function:
    addi  x3, x3, 4
    jalr  x0, x2, 0  # Return using x2 as return address
    
  jalr_ret_end:
    nop
    
  """

#-------------------------------------------------------------------------
# gen_jalr_nested_call_test
#-------------------------------------------------------------------------
# Test nested function calls with JALR

def gen_jalr_nested_call_test():
  return """
    
    # Test nested function calls
    addi  x4, x0, 1
    
    # Call func1
    lui   x1, %hi[jalr_func1]
    addi  x1, x1, %lo[jalr_func1]
    jalr  x31, x1, 0
    
    addi  x4, x4, 16
    csrw  proc2mngr, x4 > 27  # Should be 1 + 2 + 8 + 16 = 27
    jal   x0, jalr_nested_end
    
  jalr_func1:
    addi  x4, x4, 2
    
    # Save return address and call func2
    add   x30, x31, x0  # Save return address
    lui   x1, %hi[jalr_func2]
    addi  x1, x1, %lo[jalr_func2]
    jalr  x31, x1, 0
    
    # Return to main
    jalr  x0, x30, 0
    
  jalr_func2:
    addi  x4, x4, 8
    jalr  x0, x31, 0  # Return to func1
    
  jalr_nested_end:
    nop
    
  """

#-------------------------------------------------------------------------
# gen_jalr_base_eq_dest_test
#-------------------------------------------------------------------------
# Test edge case where base register equals destination register

def gen_jalr_base_eq_dest_test():
  return """
    
    # Test base register equals destination register
    addi  x3, x0, 1
    
    # Set up address in x2
    lui   x2, %hi[jalr_base_eq_target]
    addi  x2, x2, %lo[jalr_base_eq_target]
    
    # Use x2 for both base and destination
    jalr  x2, x2, 0
    addi  x3, x3, 2  # Should be skipped
    
  jalr_base_eq_target:
    # x2 now contains return address instead of target address
    addi  x3, x3, 4
    csrw  proc2mngr, x3 > 5  # Should be 1 + 4 = 5
    
  """

#-------------------------------------------------------------------------
# gen_jalr_computed_address_test
#-------------------------------------------------------------------------
# Test JALR with computed target address

def gen_jalr_computed_address_test():
  return """
    
    # Test computed target address
    addi  x3, x0, 1
    
    # Compute target address
    lui   x1, %hi[jalr_comp_base]
    addi  x1, x1, %lo[jalr_comp_base]
    addi  x2, x0, 16  # Add offset
    add   x1, x1, x2  # Compute final address
    
    jalr  x4, x1, 0
    addi  x3, x3, 2  # Should be skipped
    
  jalr_comp_base:
    nop
    nop
    nop
    nop  # 16 bytes from base
  jalr_comp_target:
    addi  x3, x3, 4
    csrw  proc2mngr, x3 > 5  # Should be 1 + 4 = 5
    
  """

#-------------------------------------------------------------------------
# gen_jalr_indirect_jump_test
#-------------------------------------------------------------------------
# Test indirect jump pattern (jump table simulation)

def gen_jalr_indirect_jump_test():
  return """
    
    # Test indirect jump (simplified jump table)
    addi  x3, x0, 1
    
    # Choose second option (index 1)
    addi  x1, x0, 1
    
    # Load base address of "jump table"
    lui   x2, %hi[jalr_option1]
    addi  x2, x2, %lo[jalr_option1]
    
    # Indirect jump to option1
    jalr  x0, x2, 0
    
  jalr_option0:
    addi  x3, x3, 2
    jal   x0, jalr_indirect_end
    
  jalr_option1:
    addi  x3, x3, 4  # This should execute
    jal   x0, jalr_indirect_end
    
  jalr_option2:
    addi  x3, x3, 8
    
  jalr_indirect_end:
    csrw  proc2mngr, x3 > 5  # Should be 1 + 4 = 5
    
  """

#-------------------------------------------------------------------------
# gen_jalr_simple_random_test
#-------------------------------------------------------------------------
# Generate simple random JALR tests

def gen_jalr_simple_random_test( offset, pattern, test_id ):
  # Clamp offset to valid 12-bit signed range
  offset = max(-1024, min(1024, offset))
  
  # Calculate the adjustment needed for the base address
  adjustment = -offset
  
  return f"""
    
    # Random JALR test {test_id} with offset {offset}
    addi  x3, x0, {pattern}
    
    # Set up target address (accounting for offset)
    lui   x1, %hi[jalr_random_target_{test_id}]
    addi  x1, x1, %lo[jalr_random_target_{test_id}]
    addi  x1, x1, {adjustment}  # Adjust base address
    
    jalr  x2, x1, {offset}   # Jump to target
    addi  x3, x3, 16         # Should be skipped
    
    nop
    nop
    nop
    nop
    
  jalr_random_target_{test_id}:
    addi  x3, x3, 1
    csrw  proc2mngr, x3 > {pattern + 1}
    
  """