#=========================================================================
# srl
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """
    csrr x1, mngr2proc < 0x80000000
    csrr x2, mngr2proc < 4
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    srl x3, x1, x2
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    csrw proc2mngr, x3 > 0x08000000
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
  """

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------

def gen_dest_dep_test():
  return [
    gen_rr_dest_dep_test( 5, "srl", 0x80000000, 1, 0x40000000 ),
    gen_rr_dest_dep_test( 4, "srl", 0x80000000, 2, 0x20000000 ),
    gen_rr_dest_dep_test( 3, "srl", 0x80000000, 3, 0x10000000 ),
    gen_rr_dest_dep_test( 2, "srl", 0x40000000, 1, 0x20000000 ),
    gen_rr_dest_dep_test( 1, "srl", 0x40000000, 2, 0x10000000 ),
    gen_rr_dest_dep_test( 0, "srl", 0x40000000, 3, 0x08000000 ),
  ]

#-------------------------------------------------------------------------
# gen_src0_dep_test
#-------------------------------------------------------------------------

def gen_src0_dep_test():
  return [
    gen_rr_src0_dep_test( 5, "srl", 0x80000000, 4, 0x08000000 ),
    gen_rr_src0_dep_test( 4, "srl", 0x80000001, 4, 0x08000000 ),
    gen_rr_src0_dep_test( 3, "srl", 0x80000008, 4, 0x08000000 ),
    gen_rr_src0_dep_test( 2, "srl", 0x40000000, 4, 0x04000000 ),
    gen_rr_src0_dep_test( 1, "srl", 0x7fffffff, 4, 0x07ffffff ),
    gen_rr_src0_dep_test( 0, "srl", 0x12345678, 4, 0x01234567 ),
  ]

#-------------------------------------------------------------------------
# gen_src1_dep_test
#-------------------------------------------------------------------------

def gen_src1_dep_test():
  return [
    gen_rr_src1_dep_test( 5, "srl", 0x80000000, 1, 0x40000000 ),
    gen_rr_src1_dep_test( 4, "srl", 0x80000000, 2, 0x20000000 ),
    gen_rr_src1_dep_test( 3, "srl", 0x80000000, 3, 0x10000000 ),
    gen_rr_src1_dep_test( 2, "srl", 0x80000000, 8, 0x00800000 ),
    gen_rr_src1_dep_test( 1, "srl", 0x80000000, 16, 0x00008000 ),
    gen_rr_src1_dep_test( 0, "srl", 0x80000000, 31, 0x00000001 ),
  ]

#-------------------------------------------------------------------------
# gen_srcs_dep_test
#-------------------------------------------------------------------------

def gen_srcs_dep_test():
  return [
    gen_rr_srcs_dep_test( 5, "srl", 0x80000000, 1, 0x40000000 ),
    gen_rr_srcs_dep_test( 4, "srl", 0x40000000, 2, 0x10000000 ),
    gen_rr_srcs_dep_test( 3, "srl", 0x20000000, 3, 0x04000000 ),
    gen_rr_srcs_dep_test( 2, "srl", 0x10000000, 4, 0x01000000 ),
    gen_rr_srcs_dep_test( 1, "srl", 0x08000000, 5, 0x00400000 ),
    gen_rr_srcs_dep_test( 0, "srl", 0x04000000, 6, 0x00100000 ),
  ]

#-------------------------------------------------------------------------
# gen_srcs_dest_test
#-------------------------------------------------------------------------

def gen_srcs_dest_test():
  return [
    gen_rr_src0_eq_dest_test( "srl", 0x80000000, 1, 0x40000000 ),
    gen_rr_src1_eq_dest_test( "srl", 0x80000000, 4, 0x08000000 ),
    gen_rr_src0_eq_src1_test( "srl", 8, 0x00000000 ),  # 8 >> 8 = 0
    gen_rr_srcs_eq_dest_test( "srl", 16, 0x00000000 ), # 16 >> 16 = 0
  ]

#-------------------------------------------------------------------------
# gen_value_test
#-------------------------------------------------------------------------

def gen_value_test():
  return [

    # Test basic zero shift
    gen_rr_value_test( "srl", 0x80000000, 0, 0x80000000 ),
    gen_rr_value_test( "srl", 0x12345678, 0, 0x12345678 ),
    gen_rr_value_test( "srl", 0x00000000, 0, 0x00000000 ),

    # Test single bit shifts (key difference from SRA)
    gen_rr_value_test( "srl", 0x80000000, 1, 0x40000000 ), # logical: zero fill
    gen_rr_value_test( "srl", 0x40000000, 1, 0x20000000 ), # same as arithmetic
    gen_rr_value_test( "srl", 0x7fffffff, 1, 0x3fffffff ), # max positive

    # Test multi-bit shifts with negative numbers (no sign extension)
    gen_rr_value_test( "srl", 0x80000000, 4, 0x08000000 ), # -2^31 >> 4 (logical)
    gen_rr_value_test( "srl", 0x80000000, 8, 0x00800000 ), # -2^31 >> 8 (logical)
    gen_rr_value_test( "srl", 0x80000000, 16, 0x00008000 ), # -2^31 >> 16 (logical)

    # Test with various negative numbers (always zero fill)
    gen_rr_value_test( "srl", 0xffffffff, 1, 0x7fffffff ), # -1 >> 1 = 0x7fffffff
    gen_rr_value_test( "srl", 0xffffffff, 4, 0x0fffffff ), # -1 >> 4 = 0x0fffffff
    gen_rr_value_test( "srl", 0xfffffffe, 1, 0x7fffffff ), # -2 >> 1 = 0x7fffffff

    # Test maximum shift (31 bits)
    gen_rr_value_test( "srl", 0x80000000, 31, 0x00000001 ), # most negative >> 31 = 1
    gen_rr_value_test( "srl", 0x7fffffff, 31, 0x00000000 ), # most positive >> 31 = 0
    gen_rr_value_test( "srl", 0xffffffff, 31, 0x00000001 ), # all 1s >> 31 = 1

    # Test shifts that use only lower 5 bits of shift amount (RISC-V spec)
    gen_rr_value_test( "srl", 0x80000000, 32, 0x80000000 ), # 32 & 0x1f = 0
    gen_rr_value_test( "srl", 0x80000000, 33, 0x40000000 ), # 33 & 0x1f = 1
    gen_rr_value_test( "srl", 0x80000000, 36, 0x08000000 ), # 36 & 0x1f = 4

    # Test various patterns
    gen_rr_value_test( "srl", 0x12345678, 4, 0x01234567 ), # positive number
    gen_rr_value_test( "srl", 0x87654321, 4, 0x08765432 ), # negative number (zero fill)
    gen_rr_value_test( "srl", 0xaaaaaaaa, 1, 0x55555555 ), # alternating pattern

    # Test edge cases that highlight difference from SRA
    gen_rr_value_test( "srl", 0x80000001, 1, 0x40000000 ), # sign + 1 (zero fill)
    gen_rr_value_test( "srl", 0x80000001, 31, 0x00000001 ), # sign + 1 >> 31 = 1
    gen_rr_value_test( "srl", 0x7ffffffe, 1, 0x3fffffff ), # max-1 positive

    # Additional comprehensive tests showing logical behavior
    gen_rr_value_test( "srl", 0x00000001, 1, 0x00000000 ), # 1 >> 1 = 0
    gen_rr_value_test( "srl", 0x00000002, 1, 0x00000001 ), # 2 >> 1 = 1
    gen_rr_value_test( "srl", 0xfffffffc, 2, 0x3fffffff ), # -4 >> 2 = large positive

    # Test all 1s pattern with various shifts
    gen_rr_value_test( "srl", 0xffffffff, 8, 0x00ffffff ), # all 1s >> 8
    gen_rr_value_test( "srl", 0xffffffff, 16, 0x0000ffff ), # all 1s >> 16
    gen_rr_value_test( "srl", 0xffffffff, 24, 0x000000ff ), # all 1s >> 24

  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():
  asm_code = []
  for i in range(100):
    src0 = b32( random.randint(0,0xffffffff) )
    # Shift amount is only lower 5 bits (0-31 for RISC-V)
    shift_amt = random.randint(0, 63)  # Test with larger values to verify masking
    effective_shift = shift_amt & 0x1f  # Only lower 5 bits matter
    
    # Perform logical right shift (always zero fill)
    result = src0.uint() >> effective_shift
    
    asm_code.append( gen_rr_value_test( "srl", src0.uint(), shift_amt, result ) )
  return asm_code