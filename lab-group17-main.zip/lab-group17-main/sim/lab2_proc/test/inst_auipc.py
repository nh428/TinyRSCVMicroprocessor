#=========================================================================
# auipc
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """
    auipc x1, 0x00010                       #
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    csrw  proc2mngr, x1 > 0x00010200
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
  """

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------

def gen_dest_dep_test():
  return [
    gen_imm_dest_dep_test( 5, "auipc", 0x00001, 0x00001200 ),  #
    gen_imm_dest_dep_test( 4, "auipc", 0x00002, 0x0000221c ),  #  
    gen_imm_dest_dep_test( 3, "auipc", 0x00003, 0x00003234 ),  #
    gen_imm_dest_dep_test( 2, "auipc", 0x00004, 0x00004248 ),  #
    gen_imm_dest_dep_test( 1, "auipc", 0x00005, 0x00005258 ),  #
    gen_imm_dest_dep_test( 0, "auipc", 0x00006, 0x00006264 ),  #
  ]

#-------------------------------------------------------------------------
# gen_value_test
#-------------------------------------------------------------------------

def gen_value_test():
  return [

    # Test zero immediate (should return current PC)
    gen_imm_value_test( "auipc", 0x00000, 0x00000200 ),  #

    # Test small positive values
    gen_imm_value_test( "auipc", 0x00001, 0x00001208 ),  #
    gen_imm_value_test( "auipc", 0x00002, 0x00002210 ),  #
    gen_imm_value_test( "auipc", 0x00007, 0x00007218 ),  #
    gen_imm_value_test( "auipc", 0x0000f, 0x0000f220 ),  #

    # Test powers of 2
    gen_imm_value_test( "auipc", 0x00010, 0x00010228 ),  #
    gen_imm_value_test( "auipc", 0x00020, 0x00020230 ),  #
    gen_imm_value_test( "auipc", 0x00040, 0x00040238 ),  #
    gen_imm_value_test( "auipc", 0x00080, 0x00080240 ),  #
    gen_imm_value_test( "auipc", 0x00100, 0x00100248 ),  #
    gen_imm_value_test( "auipc", 0x00200, 0x00200250 ),  #
    gen_imm_value_test( "auipc", 0x00400, 0x00400258 ),  #
    gen_imm_value_test( "auipc", 0x00800, 0x00800260 ),  #
    gen_imm_value_test( "auipc", 0x01000, 0x01000268 ),  #
    gen_imm_value_test( "auipc", 0x02000, 0x02000270 ),  #
    gen_imm_value_test( "auipc", 0x04000, 0x04000278 ),  #
    gen_imm_value_test( "auipc", 0x08000, 0x08000280 ),  #
    gen_imm_value_test( "auipc", 0x10000, 0x10000288 ),  #
    gen_imm_value_test( "auipc", 0x20000, 0x20000290 ),  #
    gen_imm_value_test( "auipc", 0x40000, 0x40000298 ),  #

    # Test boundary values
    gen_imm_value_test( "auipc", 0x7ffff, 0x7ffff2a0 ),  #, Maximum positive

    # Test negative values (sign extension)
    gen_imm_value_test( "auipc", 0x80000, 0x800002a8 ),  #, Most negative
    gen_imm_value_test( "auipc", 0x80001, 0x800012b0 ),  #
    gen_imm_value_test( "auipc", 0xffffe, 0xffffe2b8 ),  #
    gen_imm_value_test( "auipc", 0xfffff, 0xfffff2c0 ),  #, -1 << 12

    # Test values that will cause interesting arithmetic with PC
    gen_imm_value_test( "auipc", 0xfffff, 0xfffff2c8 ),  #, Should wrap around

    # Test specific bit patterns
    gen_imm_value_test( "auipc", 0x55555, 0x555552d0 ),  #, Alternating bits
    gen_imm_value_test( "auipc", 0xaaaaa, 0xaaaaa2d8 ),  #, Alternating bits
    gen_imm_value_test( "auipc", 0x0f0f0, 0x0f0f02e0 ),  #, Nibble pattern
    gen_imm_value_test( "auipc", 0xf0f0f, 0xf0f0f2e8 ),  #, Nibble pattern

    # Test common values
    gen_imm_value_test( "auipc", 0x12345, 0x123452f0 ),  #
    gen_imm_value_test( "auipc", 0xabcde, 0xabcde2f8 ),  #
    gen_imm_value_test( "auipc", 0xfedcb, 0xfedcb300 ),  #

  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():
  asm_code = []
  pc = 0x200
  for i in range(100):
    # Generate random 20-bit immediate value
    imm = random.randint(0, 0xfffff)
    # Calculate expected result: (immediate << 12) + PC
    # Assuming PC = 0x200 for the instruction when it executes
    result = ((imm << 12) + pc) & 0xffffffff
    asm_code.append( gen_imm_value_test( "auipc", imm, result ) )
    pc = pc + 8
  return asm_code