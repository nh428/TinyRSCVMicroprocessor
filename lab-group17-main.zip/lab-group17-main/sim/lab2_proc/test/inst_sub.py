#=========================================================================
# sub
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """
    csrr x1, mngr2proc < 5
    csrr x2, mngr2proc < 4
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    sub x3, x1, x2
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    csrw proc2mngr, x3 > 1
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
  """

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------

def gen_dest_dep_test():
  return [
    gen_rr_dest_dep_test( 5, "sub", 10, 1, 9 ),
    gen_rr_dest_dep_test( 4, "sub", 10, 2, 8 ),
    gen_rr_dest_dep_test( 3, "sub", 10, 3, 7 ),
    gen_rr_dest_dep_test( 2, "sub", 10, 4, 6 ),
    gen_rr_dest_dep_test( 1, "sub", 10, 5, 5 ),
    gen_rr_dest_dep_test( 0, "sub", 10, 6, 4 ),
  ]

#-------------------------------------------------------------------------
# gen_src0_dep_test
#-------------------------------------------------------------------------

def gen_src0_dep_test():
  return [
    gen_rr_src0_dep_test( 5, "sub", 15, 1, 14 ),
    gen_rr_src0_dep_test( 4, "sub", 16, 1, 15 ),
    gen_rr_src0_dep_test( 3, "sub", 17, 1, 16 ),
    gen_rr_src0_dep_test( 2, "sub", 18, 1, 17 ),
    gen_rr_src0_dep_test( 1, "sub", 19, 1, 18 ),
    gen_rr_src0_dep_test( 0, "sub", 20, 1, 19 ),
  ]

#-------------------------------------------------------------------------
# gen_src1_dep_test
#-------------------------------------------------------------------------

def gen_src1_dep_test():
  return [
    gen_rr_src1_dep_test( 5, "sub", 25, 13, 12 ),
    gen_rr_src1_dep_test( 4, "sub", 26, 14, 12 ),
    gen_rr_src1_dep_test( 3, "sub", 27, 15, 12 ),
    gen_rr_src1_dep_test( 2, "sub", 28, 16, 12 ),
    gen_rr_src1_dep_test( 1, "sub", 29, 17, 12 ),
    gen_rr_src1_dep_test( 0, "sub", 30, 18, 12 ),
  ]

#-------------------------------------------------------------------------
# gen_srcs_dep_test
#-------------------------------------------------------------------------

def gen_srcs_dep_test():
  return [
    gen_rr_srcs_dep_test( 5, "sub", 20, 2, 18 ),
    gen_rr_srcs_dep_test( 4, "sub", 21, 3, 18 ),
    gen_rr_srcs_dep_test( 3, "sub", 22, 4, 18 ),
    gen_rr_srcs_dep_test( 2, "sub", 23, 5, 18 ),
    gen_rr_srcs_dep_test( 1, "sub", 24, 6, 18 ),
    gen_rr_srcs_dep_test( 0, "sub", 25, 7, 18 ),
  ]

#-------------------------------------------------------------------------
# gen_srcs_dest_test
#-------------------------------------------------------------------------

def gen_srcs_dest_test():
  return [
    gen_rr_src0_eq_dest_test( "sub", 30, 1, 29 ),
    gen_rr_src1_eq_dest_test( "sub", 31, 1, 30 ),
    gen_rr_src0_eq_src1_test( "sub", 32, 0 ),
    gen_rr_srcs_eq_dest_test( "sub", 33, 0 ),
  ]

#-------------------------------------------------------------------------
# gen_value_test
#-------------------------------------------------------------------------

def gen_value_test():
  return [

    # Basic zero cases
    gen_rr_value_test( "sub", 0x00000000, 0x00000000, 0x00000000 ),
    gen_rr_value_test( "sub", 0x00000001, 0x00000001, 0x00000000 ),
    gen_rr_value_test( "sub", 0x0000000a, 0x00000007, 0x00000003 ),

    # Positive - negative cases (result positive)
    gen_rr_value_test( "sub", 0x00000000, 0xffff8000, 0x00008000 ),
    gen_rr_value_test( "sub", 0x80000000, 0x00000000, 0x80000000 ),
    gen_rr_value_test( "sub", 0x80000000, 0xffff8000, 0x80008000 ),

    # Positive cases with max values
    gen_rr_value_test( "sub", 0x00007fff, 0x00000000, 0x00007fff ),
    gen_rr_value_test( "sub", 0x7fffffff, 0x00000000, 0x7fffffff ),
    gen_rr_value_test( "sub", 0x7fffffff, 0x00007fff, 0x7fff8000 ),

    # Mixed sign cases
    gen_rr_value_test( "sub", 0x80000000, 0x00007fff, 0x7fff8001 ),
    gen_rr_value_test( "sub", 0x7fffffff, 0xffff8000, 0x80007fff ),

    # Edge cases with -1 and overflow scenarios
    gen_rr_value_test( "sub", 0x00000000, 0xffffffff, 0x00000001 ),
    gen_rr_value_test( "sub", 0xffffffff, 0x00000001, 0xfffffffe ),
    gen_rr_value_test( "sub", 0xffffffff, 0xffffffff, 0x00000000 ),

    # Additional edge cases specific to subtraction
    gen_rr_value_test( "sub", 0x00000001, 0x00000000, 0x00000001 ),
    gen_rr_value_test( "sub", 0x80000000, 0x80000000, 0x00000000 ),
    gen_rr_value_test( "sub", 0x7fffffff, 0x7fffffff, 0x00000000 ),

    # Underflow scenarios
    gen_rr_value_test( "sub", 0x00000000, 0x00000001, 0xffffffff ),
    gen_rr_value_test( "sub", 0x80000000, 0x00000001, 0x7fffffff ),

  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():
  asm_code = []
  for i in range(100):
    src0 = b32( random.randint(0,0xffffffff) )
    src1 = b32( random.randint(0,0xffffffff) )
    dest = src0 - src1
    asm_code.append( gen_rr_value_test( "sub", src0.uint(), src1.uint(), dest.uint() ) )
  return asm_code