#=========================================================================
# sra
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """
    csrr x1, mngr2proc < 0x80000000
    csrr x2, mngr2proc < 4
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    sra x3, x1, x2
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    csrw proc2mngr, x3 > 0xf8000000
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
  """

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------

def gen_dest_dep_test():
  return [
    gen_rr_dest_dep_test( 5, "sra", 0x80000000, 1, 0xc0000000 ),
    gen_rr_dest_dep_test( 4, "sra", 0x80000000, 2, 0xe0000000 ),
    gen_rr_dest_dep_test( 3, "sra", 0x80000000, 3, 0xf0000000 ),
    gen_rr_dest_dep_test( 2, "sra", 0x40000000, 1, 0x20000000 ),
    gen_rr_dest_dep_test( 1, "sra", 0x40000000, 2, 0x10000000 ),
    gen_rr_dest_dep_test( 0, "sra", 0x40000000, 3, 0x08000000 ),
  ]

#-------------------------------------------------------------------------
# gen_src0_dep_test
#-------------------------------------------------------------------------

def gen_src0_dep_test():
  return [
    gen_rr_src0_dep_test( 5, "sra", 0x80000000, 4, 0xf8000000 ),
    gen_rr_src0_dep_test( 4, "sra", 0x80000001, 4, 0xf8000000 ),
    gen_rr_src0_dep_test( 3, "sra", 0x80000008, 4, 0xf8000000 ),
    gen_rr_src0_dep_test( 2, "sra", 0x40000000, 4, 0x04000000 ),
    gen_rr_src0_dep_test( 1, "sra", 0x7fffffff, 4, 0x07ffffff ),
    gen_rr_src0_dep_test( 0, "sra", 0x12345678, 4, 0x01234567 ),
  ]

#-------------------------------------------------------------------------
# gen_src1_dep_test
#-------------------------------------------------------------------------

def gen_src1_dep_test():
  return [
    gen_rr_src1_dep_test( 5, "sra", 0x80000000, 1, 0xc0000000 ),
    gen_rr_src1_dep_test( 4, "sra", 0x80000000, 2, 0xe0000000 ),
    gen_rr_src1_dep_test( 3, "sra", 0x80000000, 3, 0xf0000000 ),
    gen_rr_src1_dep_test( 2, "sra", 0x80000000, 8, 0xff800000 ),
    gen_rr_src1_dep_test( 1, "sra", 0x80000000, 16, 0xffff8000 ),
    gen_rr_src1_dep_test( 0, "sra", 0x80000000, 31, 0xffffffff ),
  ]

#-------------------------------------------------------------------------
# gen_srcs_dep_test
#-------------------------------------------------------------------------

def gen_srcs_dep_test():
  return [
    gen_rr_srcs_dep_test( 5, "sra", 0x80000000, 1, 0xc0000000 ),
    gen_rr_srcs_dep_test( 4, "sra", 0x40000000, 2, 0x10000000 ),
    gen_rr_srcs_dep_test( 3, "sra", 0x20000000, 3, 0x04000000 ),
    gen_rr_srcs_dep_test( 2, "sra", 0x10000000, 4, 0x01000000 ),
    gen_rr_srcs_dep_test( 1, "sra", 0x08000000, 5, 0x00400000 ),
    gen_rr_srcs_dep_test( 0, "sra", 0x04000000, 6, 0x00100000 ),
  ]

#-------------------------------------------------------------------------
# gen_srcs_dest_test
#-------------------------------------------------------------------------

def gen_srcs_dest_test():
  return [
    gen_rr_src0_eq_dest_test( "sra", 0x80000000, 1, 0xc0000000 ),
    gen_rr_src1_eq_dest_test( "sra", 0x80000000, 4, 0xf8000000 ),
    gen_rr_src0_eq_src1_test( "sra", 8, 0x00000000 ),  # 8 >> 8 = 0
    gen_rr_srcs_eq_dest_test( "sra", 16, 0x00000000 ), # 16 >> 16 = 0
  ]

#-------------------------------------------------------------------------
# gen_value_test
#-------------------------------------------------------------------------

def gen_value_test():
  return [

    # Test basic zero shift
    gen_rr_value_test( "sra", 0x80000000, 0, 0x80000000 ),
    gen_rr_value_test( "sra", 0x12345678, 0, 0x12345678 ),
    gen_rr_value_test( "sra", 0x00000000, 0, 0x00000000 ),

    # Test single bit shifts with positive numbers
    gen_rr_value_test( "sra", 0x80000000, 1, 0xc0000000 ), # sign extension
    gen_rr_value_test( "sra", 0x40000000, 1, 0x20000000 ), # no sign extension
    gen_rr_value_test( "sra", 0x7fffffff, 1, 0x3fffffff ), # max positive

    # Test multi-bit shifts with negative numbers
    gen_rr_value_test( "sra", 0x80000000, 4, 0xf8000000 ), # -2^31 >> 4
    gen_rr_value_test( "sra", 0x80000000, 8, 0xff800000 ), # -2^31 >> 8
    gen_rr_value_test( "sra", 0x80000000, 16, 0xffff8000 ), # -2^31 >> 16

    # Test with small negative numbers
    gen_rr_value_test( "sra", 0xffffffff, 1, 0xffffffff ), # -1 >> 1 = -1
    gen_rr_value_test( "sra", 0xffffffff, 4, 0xffffffff ), # -1 >> 4 = -1
    gen_rr_value_test( "sra", 0xfffffffe, 1, 0xffffffff ), # -2 >> 1 = -1

    # Test maximum shift (31 bits)
    gen_rr_value_test( "sra", 0x80000000, 31, 0xffffffff ), # most negative >> 31 = -1
    gen_rr_value_test( "sra", 0x7fffffff, 31, 0x00000000 ), # most positive >> 31 = 0
    gen_rr_value_test( "sra", 0x40000000, 31, 0x00000000 ), # positive >> 31 = 0

    # Test shifts that use only lower 5 bits of shift amount (RISC-V spec)
    gen_rr_value_test( "sra", 0x80000000, 32, 0x80000000 ), # 32 & 0x1f = 0
    gen_rr_value_test( "sra", 0x80000000, 33, 0xc0000000 ), # 33 & 0x1f = 1
    gen_rr_value_test( "sra", 0x80000000, 36, 0xf8000000 ), # 36 & 0x1f = 4

    # Test various patterns
    gen_rr_value_test( "sra", 0x12345678, 4, 0x01234567 ), # positive number
    gen_rr_value_test( "sra", 0x87654321, 4, 0xf8765432 ), # negative number
    gen_rr_value_test( "sra", 0xaaaaaaaa, 1, 0xd5555555 ), # alternating pattern

    # Test edge cases around sign bit
    gen_rr_value_test( "sra", 0x80000001, 1, 0xc0000000 ), # sign + 1
    gen_rr_value_test( "sra", 0x80000001, 31, 0xffffffff ), # sign + 1 >> 31
    gen_rr_value_test( "sra", 0x7ffffffe, 1, 0x3fffffff ), # max-1 positive

    # Additional comprehensive tests
    gen_rr_value_test( "sra", 0x00000001, 1, 0x00000000 ), # 1 >> 1 = 0
    gen_rr_value_test( "sra", 0x00000002, 1, 0x00000001 ), # 2 >> 1 = 1
    gen_rr_value_test( "sra", 0xfffffffc, 2, 0xffffffff ), # -4 >> 2 = -1

  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():
  asm_code = []
  for i in range(100):
    src0 = b32( random.randint(0,0xffffffff) )
    # Shift amount is only lower 5 bits (0-31 for RISC-V)
    shift_amt = random.randint(0, 63)  # Test with larger values to verify masking
    effective_shift = shift_amt & 0x1f  # Only lower 5 bits matter
    
    # Perform arithmetic right shift
    if src0.uint() & 0x80000000:  # Negative number
      # Sign extend: fill with 1s from the left
      result = (src0.uint() >> effective_shift) | (0xffffffff << (32 - effective_shift)) if effective_shift > 0 else src0.uint()
      result = result & 0xffffffff  # Keep it 32-bit
    else:  # Positive number
      result = src0.uint() >> effective_shift
    
    asm_code.append( gen_rr_value_test( "sra", src0.uint(), shift_amt, result ) )
  return asm_code