#=========================================================================
# jal
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """

    # Use r3 to track the control flow pattern
    addi  x3, x0, 0     # 0x0200
                        #
    nop                 # 0x0204
    nop                 # 0x0208
    nop                 # 0x020c
    nop                 # 0x0210
    nop                 # 0x0214
    nop                 # 0x0218
    nop                 # 0x021c
    nop                 # 0x0220
                        #
    jal   x1, label_a   # 0x0224
    addi  x3, x3, 0b01  # 0x0228

    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop

  label_a:
    addi  x3, x3, 0b10

    # Check the link address
    csrw  proc2mngr, x1 > 0x0228

    # Only the second bit should be set if jump was taken
    csrw  proc2mngr, x3 > 0b10

  """

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------
# Test the destination bypass path by varying how many nops are
# inserted between the JAL instruction and reading the destination
# register with a csrw instruction.

def gen_dest_dep_test():
  return [
    gen_jal_dest_dep_test( 5 ),
    gen_jal_dest_dep_test( 4 ),
    gen_jal_dest_dep_test( 3 ),
    gen_jal_dest_dep_test( 2 ),
    gen_jal_dest_dep_test( 1 ),
    gen_jal_dest_dep_test( 0 ),
  ]

#-------------------------------------------------------------------------
# gen_link_dep_test
#-------------------------------------------------------------------------
# Test using the link register immediately after the JAL with various
# numbers of nops to test bypass paths

def gen_link_dep_test():
  return [
    gen_jal_link_dep_test( 5 ),
    gen_jal_link_dep_test( 4 ),
    gen_jal_link_dep_test( 3 ),
    gen_jal_link_dep_test( 2 ),
    gen_jal_link_dep_test( 1 ),
    gen_jal_link_dep_test( 0 ),
  ]

#-------------------------------------------------------------------------
# gen_jump_test
#-------------------------------------------------------------------------
# Test various jump distances and control flow patterns

def gen_jump_test():
  return [
    gen_jal_forward_test(),
    gen_jal_backward_test(),
    gen_jal_immediate_test(),
  ]

#-------------------------------------------------------------------------
# gen_link_register_test
#-------------------------------------------------------------------------
# Test different link registers including x0 (which discards the link)

def gen_link_register_test():
  return [
    gen_jal_link_x0_test(),
    gen_jal_link_x31_test(),
  ]

#-------------------------------------------------------------------------
# gen_control_flow_test
#-------------------------------------------------------------------------
# Test complex control flow patterns with multiple JAL instructions

def gen_control_flow_test():
  return [
    # gen_jal_nested_simple_test(),
    gen_jal_sequential_test(),
  ]

#-------------------------------------------------------------------------
# gen_edge_case_test
#-------------------------------------------------------------------------
# Test edge cases

def gen_edge_case_test():
  return [
    gen_jal_same_reg_test(),
    gen_jal_zero_offset_test(),
  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():
  asm_code = []
  for i in range(10):
    # Generate simple random tests focusing on control flow
    control_pattern = random.randint(1, 15)
    asm_code.append( gen_jal_simple_random_test( control_pattern, i ) )
  return asm_code

# Helper functions for generating specific JAL tests

#-------------------------------------------------------------------------
# gen_jal_dest_dep_test
#-------------------------------------------------------------------------
# Test destination dependency - can we read the link register after nops?

def gen_jal_dest_dep_test( num_nops ):
  return f"""
    
    # Test destination dependency with {num_nops} nops
    addi  x3, x0, 0b01
    
    jal   x1, target_{num_nops}
    addi  x3, x3, 0b10  # Should be skipped
    
  target_{num_nops}:
    addi  x3, x3, 0b100
    {gen_nops(num_nops)}
    
    # Test that we can read the link register
    add   x2, x1, x0  # Copy link register 
    csrw  proc2mngr, x3 > 0b101  # Should have bits 0 and 2 set
    
  """

#-------------------------------------------------------------------------
# gen_jal_link_dep_test  
#-------------------------------------------------------------------------
# Test using the link register immediately after JAL

def gen_jal_link_dep_test( num_nops ):
  return f"""
    
    # Test link register dependency with {num_nops} nops
    addi  x3, x0, 1
    
    jal   x2, link_target_{num_nops}
    addi  x3, x3, 2  # Should be skipped
    
  link_target_{num_nops}:
    {gen_nops(num_nops)}
    # Use link register in arithmetic - test that bypassing works
    add   x4, x2, x3
    csrw  proc2mngr, x3 > 1  # Should still be 1
    
  """

#-------------------------------------------------------------------------
# gen_jal_forward_test
#-------------------------------------------------------------------------
# Test forward jump

def gen_jal_forward_test():
  return """
    
    # Test forward jump
    addi  x3, x0, 1
    
    jal   x1, forward_target
    addi  x3, x3, 2  # Should be skipped
    
    nop
    nop
    nop
    nop
    
  forward_target:
    addi  x3, x3, 4
    csrw  proc2mngr, x3 > 5  # Should be 0b001 + 0b100 = 0b101
    
  """

#-------------------------------------------------------------------------
# gen_jal_backward_test
#-------------------------------------------------------------------------
# Test backward jump

def gen_jal_backward_test():
  return """
    
    # Test backward jump
    addi  x3, x0, 0
    jal   x0, backward_start
    
  backward_target:
    addi  x3, x3, 4
    csrw  proc2mngr, x3 > 5  # Should be 0b001 + 0b100 = 0b101
    jal   x0, backward_end
    
  backward_start:
    addi  x3, x3, 1
    jal   x1, backward_target
    addi  x3, x3, 2  # Should be skipped
    
  backward_end:
    nop
    
  """

#-------------------------------------------------------------------------
# gen_jal_immediate_test
#-------------------------------------------------------------------------
# Test jump to immediately following instruction

def gen_jal_immediate_test():
  return """
    
    # Test jump to next instruction (essentially a NOP with link)
    addi  x3, x0, 1
    
    jal   x1, immediate_target
    
  immediate_target:
    addi  x3, x3, 2
    csrw  proc2mngr, x3 > 3  # Should be 1 + 2 = 3
    
  """

#-------------------------------------------------------------------------
# gen_jal_link_x0_test
#-------------------------------------------------------------------------
# Test JAL with x0 as destination (should discard return address)

def gen_jal_link_x0_test():
  return """
    
    # Test JAL with x0 as link register
    addi  x3, x0, 0b01
    
    jal   x0, x0_target
    addi  x3, x3, 0b10  # Should be skipped
    
  x0_target:
    addi  x3, x3, 0b100
    
    # x0 should always be zero
    csrw  proc2mngr, x0 > 0
    csrw  proc2mngr, x3 > 0b101
    
  """

#-------------------------------------------------------------------------
# gen_jal_link_x31_test
#-------------------------------------------------------------------------
# Test JAL with x31 as destination

def gen_jal_link_x31_test():
  return """
    
    # Test JAL with x31 as link register
    addi  x3, x0, 0b01
    
    jal   x31, x31_target
    addi  x3, x3, 0b10  # Should be skipped
    
  x31_target:
    addi  x3, x3, 0b100
    
    # Just verify the control flow worked correctly
    csrw  proc2mngr, x3 > 0b101
    
  """

#-------------------------------------------------------------------------
# gen_jal_nested_simple_test
#-------------------------------------------------------------------------
# Simple nested JAL test

def gen_jal_nested_simple_test():
  return """
    
    
    addi  x4, x0, 1           # x200
    jal   x1, func1           # x204
    addi  x4, x4, 8           # x208
    csrw  proc2mngr, x4 > 23  # x20c

  func1:
    addi  x4, x4, 2           # x210
    jal   x2, func2           # x214
    addi  x4, x4, 8           # x218
    jalr  x0, x1, 0           # x21c

  func2:
    addi  x4, x4, 4           # x220
    jalr  x0, x2, 0           # x224
    
  """

#-------------------------------------------------------------------------
# gen_jal_sequential_test
#-------------------------------------------------------------------------
# Test multiple sequential JAL instructions

def gen_jal_sequential_test():
  return """
    
    # Test sequential JAL instructions
    addi  x3, x0, 1       # x200
    
    jal   x1, seq_target1 # x204
    addi  x3, x3, 16      # x208  
    
  seq_continue:
    jal   x2, seq_target2 # x20c
    addi  x3, x3, 32      # x210

    csrw  proc2mngr, x3 > 0x27 # x214
    jal   x5, seq_end      # x218 
    
  seq_target1:
    addi  x3, x3, 2     # x21c  
    jal   x6, seq_continue # x220
    
  seq_target2:
    addi  x3, x3, 4    # x224
    jalr  x0, x2, 0  # x228, Return
    
  seq_end:
    nop   # x22c
    
  """

#-------------------------------------------------------------------------
# gen_jal_same_reg_test
#-------------------------------------------------------------------------
# Test JAL where the link register is used in the computation

def gen_jal_same_reg_test():
  return """
    
    # Test using link register in target
    addi  x3, x0, 1
    
    jal   x3, same_reg_target
    addi  x3, x3, 2  # Should be skipped
    
  same_reg_target:
    # x3 now contains the return address, not 1
    # Just verify we reached this point by setting a known value
    addi  x4, x0, 42
    csrw  proc2mngr, x4 > 42
    
  """

#-------------------------------------------------------------------------
# gen_jal_zero_offset_test
#-------------------------------------------------------------------------
# Test JAL with zero offset (jump to next instruction)

def gen_jal_zero_offset_test():
  return """
    
    # Test zero offset
    addi  x3, x0, 5
    jal   x1, zero_offset_target
    
  zero_offset_target:
    addi  x3, x3, 3
    # Just verify the control flow worked
    csrw  proc2mngr, x3 > 8
    
  """

#-------------------------------------------------------------------------
# gen_jal_simple_random_test
#-------------------------------------------------------------------------
# Generate simple random JAL tests

def gen_jal_simple_random_test( pattern, test_id ):
  return f"""
    
    # Random JAL test {test_id}
    addi  x3, x0, {pattern}
    
    jal   x1, random_target_{test_id}
    addi  x3, x3, 16  # Should be skipped
    
  random_target_{test_id}:
    addi  x3, x3, 1
    csrw  proc2mngr, x3 > {pattern + 1}
    
  """