#=========================================================================
# slti
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """
    csrr x1, mngr2proc < 5
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    slti x3, x1, 6
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    csrw proc2mngr, x3 > 1
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
  """

# ''' LAB TASK ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
# Define additional directed and random test cases.
# '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
#=========================================================================
# slti
#=========================================================================

import random

# Fix the random seed so results are reproducible
random.seed(0xdeadbeef)

from pymtl3 import *
from lab2_proc.test.inst_utils import *

#-------------------------------------------------------------------------
# gen_basic_test
#-------------------------------------------------------------------------

def gen_basic_test():
  return """
    csrr x1, mngr2proc < 4
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    slti x3, x1, 5
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    csrw proc2mngr, x3 > 1
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
  """

#-------------------------------------------------------------------------
# gen_dest_dep_test
#-------------------------------------------------------------------------

def gen_dest_dep_test():
  return [
    gen_rimm_dest_dep_test( 5, "slti", 1, 2, 1 ),
    gen_rimm_dest_dep_test( 4, "slti", 3, 4, 1 ),
    gen_rimm_dest_dep_test( 3, "slti", 5, 6, 1 ),
    gen_rimm_dest_dep_test( 2, "slti", 7, 8, 1 ),
    gen_rimm_dest_dep_test( 1, "slti", 9, 10, 1 ),
    gen_rimm_dest_dep_test( 0, "slti", 11, 12, 1 ),
  ]

#-------------------------------------------------------------------------
# gen_src_dep_test
#-------------------------------------------------------------------------

def gen_src_dep_test():
  return [
    gen_rimm_src_dep_test( 5, "slti", 15, 14, 0 ),
    gen_rimm_src_dep_test( 4, "slti", 16, 15, 0 ),
    gen_rimm_src_dep_test( 3, "slti", 17, 16, 0 ),
    gen_rimm_src_dep_test( 2, "slti", 18, 17, 0 ),
    gen_rimm_src_dep_test( 1, "slti", 19, 18, 0 ),
    gen_rimm_src_dep_test( 0, "slti", 20, 19, 0 ),
  ]

#-------------------------------------------------------------------------
# gen_src_eq_dest_test
#-------------------------------------------------------------------------

def gen_src_eq_dest_test():
  return [
    gen_rimm_src_eq_dest_test( "slti", 25, 30, 1 ),
    gen_rimm_src_eq_dest_test( "slti", 35, 30, 0 ),
    gen_rimm_src_eq_dest_test( "slti", 40, 0x800, 0 ), # 40 < -2048 = false
  ]

#-------------------------------------------------------------------------
# gen_value_test
#-------------------------------------------------------------------------

def gen_value_test():
  return [

    # Basic comparison tests
    gen_rimm_value_test( "slti", 0x00000000, 0x000, 0x00000000 ), # 0 < 0 = false
    gen_rimm_value_test( "slti", 0x00000000, 0x001, 0x00000001 ), # 0 < 1 = true
    gen_rimm_value_test( "slti", 0x00000001, 0x000, 0x00000000 ), # 1 < 0 = false
    gen_rimm_value_test( "slti", 0x00000001, 0x001, 0x00000000 ), # 1 < 1 = false

    # Small positive number comparisons
    gen_rimm_value_test( "slti", 0x00000003, 0x007, 0x00000001 ), # 3 < 7 = true
    gen_rimm_value_test( "slti", 0x00000007, 0x003, 0x00000000 ), # 7 < 3 = false

    # Test with negative immediates (0x800 = -2048, 0xfff = -1)
    gen_rimm_value_test( "slti", 0x00000000, 0xfff, 0x00000000 ), # 0 < -1 = false
    gen_rimm_value_test( "slti", 0xffffffff, 0x000, 0x00000001 ), # -1 < 0 = true
    gen_rimm_value_test( "slti", 0xffffffff, 0xfff, 0x00000000 ), # -1 < -1 = false

    # Test with large negative vs positive
    gen_rimm_value_test( "slti", 0x80000000, 0x001, 0x00000001 ), # most neg < 1 = true
    gen_rimm_value_test( "slti", 0x00000001, 0x800, 0x00000000 ), # 1 < -2048 = false
    gen_rimm_value_test( "slti", 0x80000000, 0x7ff, 0x00000001 ), # most neg < 2047 = true

    # Test boundary immediate values
    gen_rimm_value_test( "slti", 0x7fffffff, 0x800, 0x00000000 ), # most pos < -2048 = false
    gen_rimm_value_test( "slti", 0x80000000, 0x800, 0x00000001 ), # most neg < -2048 = true
    gen_rimm_value_test( "slti", 0x7fffffff, 0x7ff, 0x00000000 ), # most pos < 2047 = false

    # Test comparing with maximum positive immediate (2047)
    gen_rimm_value_test( "slti", 0x000007fe, 0x7ff, 0x00000001 ), # 2046 < 2047 = true
    gen_rimm_value_test( "slti", 0x000007ff, 0x7ff, 0x00000000 ), # 2047 < 2047 = false
    gen_rimm_value_test( "slti", 0x00000800, 0x7ff, 0x00000000 ), # 2048 < 2047 = false

    # Test comparing with maximum negative immediate (-2048)
    gen_rimm_value_test( "slti", 0xfffff7ff, 0x800, 0x00000001 ), # -2049 < -2048 = true
    gen_rimm_value_test( "slti", 0xfffff800, 0x800, 0x00000000 ), # -2048 < -2048 = false
    gen_rimm_value_test( "slti", 0xfffff801, 0x800, 0x00000000 ), # -2047 < -2048 = false

    # Test negative number comparisons with negative immediates
    gen_rimm_value_test( "slti", 0xfffffffe, 0xfff, 0x00000001 ), # -2 < -1 = true
    gen_rimm_value_test( "slti", 0xffffffff, 0xffe, 0x00000000 ), # -1 < -2 = false
    gen_rimm_value_test( "slti", 0x80000001, 0x800, 0x00000001 ), # -2147483647 < -2048 = true

    # Additional edge cases with sign extension
    gen_rimm_value_test( "slti", 0x00000000, 0x7ff, 0x00000001 ), # 0 < max_pos_imm = true
    gen_rimm_value_test( "slti", 0x000007ff, 0x000, 0x00000000 ), # max_pos_imm < 0 = false
    gen_rimm_value_test( "slti", 0x80000000, 0x000, 0x00000001 ), # min_neg < 0 = true

    # Test with various small negative immediates
    gen_rimm_value_test( "slti", 0x00000010, 0xfff, 0x00000000 ), # 16 < -1 = false
    gen_rimm_value_test( "slti", 0xfffffff0, 0xfff, 0x00000001 ), # -16 < -1 = true
    gen_rimm_value_test( "slti", 0xfffffff0, 0xff0, 0x00000000 ), # -16 < -16 = false

    # Test zero immediate
    gen_rimm_value_test( "slti", 0x12345678, 0x000, 0x00000000 ), # positive < 0 = false
    gen_rimm_value_test( "slti", 0xfedcba98, 0x000, 0x00000001 ), # negative < 0 = true

    # Additional boundary tests
    gen_rimm_value_test( "slti", 0x00000001, 0xfff, 0x00000000 ), # 1 < -1 = false
    gen_rimm_value_test( "slti", 0xffffffff, 0x001, 0x00000001 ), # -1 < 1 = true

  ]

#-------------------------------------------------------------------------
# gen_random_test
#-------------------------------------------------------------------------

def gen_random_test():
  asm_code = []
  for i in range(100):
    src = b32( random.randint(0,0xffffffff) )
    # Generate 12-bit signed immediate (-2048 to 2047)
    imm_val = random.randint(-2048, 2047)
    # Convert to 12-bit representation for encoding
    if imm_val < 0:
      imm = (imm_val + 4096) & 0xfff  # Two's complement in 12 bits
    else:
      imm = imm_val & 0xfff
    
    # SLTI performs signed comparison between src and sign-extended immediate
    src_signed = src.int()
    imm_signed = imm_val  # Already the correct signed value
    result = 1 if src_signed < imm_signed else 0
    
    asm_code.append( gen_rimm_value_test( "slti", src.uint(), imm, result ) )
  return asm_code