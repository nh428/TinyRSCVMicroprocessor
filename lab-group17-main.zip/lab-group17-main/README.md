# lab-group17

ECE 4750 Lab Assignments for Fall 2025

This is the student repository for:

Ivan Mokeyev (ism27, smokevan)

Nate Haris (nh428, nh428)

